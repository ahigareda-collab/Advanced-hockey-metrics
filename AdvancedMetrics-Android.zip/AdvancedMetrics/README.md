# Advanced Metrics Tracker for Android

A native Android app (Kotlin + Jetpack Compose) for tracking faceoffs, zone entries and exits, turnovers,
power-play goals, one-timers and board battles from the bench. It does everything the web tracker does
and works with no signal at the rink.

- **Track:** period buttons, Undo and the game log stay pinned at the top. Tap a stat, then tap the
  player's number. The screen stays awake while you're on this tab.
- **Stats:** this game or the season, filtered by period. Save Excel (with working formulas) or PDF
  reports, or copy a table to paste into Excel or Sheets.
- **Setup:** teams, roster (or paste a whole list), games, player credit on or off, and backups.

It needs Android 8.0 or newer.

## Option A: build it online with GitHub (nothing to install)

1. Make a free account at github.com, then create a **New repository**. Set it to **Private**.
2. On the new repository page, click **uploading an existing file**. Drag in everything inside this
   folder, including the `.github` folder, then click **Commit changes**.
   - If your computer hides the `.github` folder, open the **Actions** tab, choose
     **set up a workflow yourself**, paste in the contents of `.github/workflows/build.yml`, and commit.
3. Open the **Actions** tab. The **Build APK** run starts by itself and takes about 5–8 minutes.
   When it shows a green check, open it and download **AdvancedMetrics-apk** at the bottom.
4. Unzip the download to get `app-release.apk`, then put that file on your phone (or do steps 3–4 on
   the phone itself).
5. On the phone, tap the APK. Android asks you to allow installs from that app (Files or Chrome).
   Allow it, then tap **Install**.

## Option B: build it with Android Studio

1. Install Android Studio (free) and open this folder with **File › Open**.
2. Plug in your phone with USB debugging turned on and press the green **Run** button. To get a file
   instead, use **Build › Build App Bundle(s) / APK(s) › Build APK(s)**.

## Bringing over stats from the web tracker

In the web tracker, go to **Setup › Save backup file**. In the app, go to **Setup › Restore a backup ›
Choose a backup file**. You can also use **Copy backup** in the web tracker and paste it into the
app's restore box. Backups work both ways.

## Updates

Every build is signed with the same key (`app/personal.keystore`), so a newer APK installs over the old
one and keeps your stats. Don't delete that file. The key's password is in `app/build.gradle.kts`,
which is fine for a private, personal app. Keep the repository private.

## Code layout

- `core/`: tracking rules, stats, roster paste, the Excel writer and the backup format. It's plain
  Kotlin with tests in `app/src/test`.
- `ui/`: the screens, bottom sheets, PDF reports and theme.
