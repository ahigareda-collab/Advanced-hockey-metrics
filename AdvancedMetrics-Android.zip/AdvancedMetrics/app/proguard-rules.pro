# No reflection or serialization libraries are used, so the default Android rules are enough.
