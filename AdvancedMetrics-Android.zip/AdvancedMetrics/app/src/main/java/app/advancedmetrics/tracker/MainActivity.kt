package app.advancedmetrics.tracker

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import app.advancedmetrics.tracker.ui.App
import app.advancedmetrics.tracker.ui.AppViewModel
import app.advancedmetrics.tracker.ui.MetricsTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MetricsTheme {
                val vm: AppViewModel = viewModel()
                App(vm)
            }
        }
    }
}
