package app.advancedmetrics.tracker.core

/**
 * Everything the app can do to the data. Each change replaces [data] with an updated copy,
 * so the screens always see a consistent snapshot. No Android code here, so it is unit-tested.
 */
class Engine(initial: AppData) {
    var data: AppData = initial
        private set

    sealed interface Undo { val gid: String }
    data class UAdd(override val gid: String, val id: String) : Undo
    data class UDel(override val gid: String, val ev: Ev, val idx: Int) : Undo
    data class UEdit(override val gid: String, val id: String, val per: String, val p: String?) : Undo

    private val undoStack = ArrayList<Undo>()
    /** Last player picked per stat this session, highlighted in the picker. "" = team only. */
    val lastPick = HashMap<String, String>()
    /** Older games the user chose to keep logging to without being reminded. */
    val keepOld = HashSet<String>()

    fun replace(d: AppData) { data = d; undoStack.clear(); keepOld.clear() }

    /* ---------- Reading ---------- */
    fun team(): Team = data.teams.find { it.id == data.teamId } ?: data.teams[0]
    fun game(): Game? = team().let { t -> t.games.find { it.id == t.gameId } }
    fun player(id: String?): Player? = id?.let { pid -> team().roster.find { it.id == pid } }
    fun activeRoster(): List<Player> = team().roster.filter { !it.gone }.sortedWith(byNum)
    fun askingWho(): Boolean = data.askWho && activeRoster().isNotEmpty()
    fun pName(id: String?): String {
        val p = player(id) ?: return "Removed player"
        return (if (p.num.isNotEmpty()) "#${p.num} " else "") + p.name
    }
    fun descEv(e: Ev): String = EV.getValue(e.k).name + (e.p?.let { " · " + pName(it) } ?: "")
    fun canUndo(): Boolean { val g = game() ?: return false; return g.events.isNotEmpty() || undoStack.any { it.gid == g.id } }

    /* ---------- Updating helpers ---------- */
    private fun setTeam(f: (Team) -> Team) {
        val id = team().id
        data = data.copy(teams = data.teams.map { if (it.id == id) f(it) else it })
    }
    private fun setGame(gid: String, f: (Game) -> Game) = setTeam { t -> t.copy(games = t.games.map { if (it.id == gid) f(it) else it }) }
    private fun push(u: Undo) { undoStack.add(u); if (undoStack.size > 200) undoStack.removeAt(0) }

    /* ---------- Tracking ---------- */
    fun setPeriod(p: String): Boolean {
        if (p !in PERS || p == data.per) return false
        data = data.copy(per = p); return true
    }

    fun logEvent(k: String, pid: String?, now: Long = System.currentTimeMillis()): Ev? {
        val g = game() ?: return null
        val type = EV[k] ?: return null
        val p = if (type.ind && pid != null && player(pid) != null) pid else null
        val ev = Ev(uid(), k, p, data.per, now)
        setGame(g.id) { it.copy(events = it.events + ev) }
        push(UAdd(g.id, ev.id))
        if (type.ind) lastPick[k] = p ?: ""
        return ev
    }
    fun logMessage(ev: Ev): String {
        val type = EV.getValue(ev.k)
        return type.name + (if (ev.p != null) " · " + pName(ev.p) else if (type.ind) " · Team only" else "") + " · " + perShort(ev.per)
    }

    /** Walks back this session's changes to the current game, newest first; then removes the latest entry. */
    fun undo(): String? {
        val g = game() ?: return null
        for (i in undoStack.indices.reversed()) {
            val a = undoStack[i]
            if (a.gid != g.id) continue
            undoStack.removeAt(i)
            val cur = game()!!
            when (a) {
                is UAdd -> {
                    val e = cur.events.find { it.id == a.id } ?: continue
                    setGame(g.id) { gg -> gg.copy(events = gg.events.filter { it.id != a.id }) }
                    return "Undone: " + descEv(e)
                }
                is UDel -> {
                    setGame(g.id) { gg -> gg.copy(events = gg.events.toMutableList().also { it.add(minOf(a.idx, it.size), a.ev) }) }
                    return "Restored: " + descEv(a.ev)
                }
                is UEdit -> {
                    if (cur.events.none { it.id == a.id }) continue
                    setGame(g.id) { gg -> gg.copy(events = gg.events.map { if (it.id == a.id) it.copy(per = a.per, p = a.p) else it }) }
                    val e = game()!!.events.first { it.id == a.id }
                    return "Change undone: " + descEv(e) + " · " + perShort(e.per)
                }
            }
        }
        val e = g.events.lastOrNull() ?: return null
        setGame(g.id) { it.copy(events = it.events.dropLast(1)) }
        return "Removed: " + descEv(e)
    }

    fun deleteEntry(id: String): String? {
        val g = game() ?: return null
        val i = g.events.indexOfFirst { it.id == id }
        if (i < 0) return null
        val ev = g.events[i]
        setGame(g.id) { gg -> gg.copy(events = gg.events.filter { it.id != id }) }
        push(UDel(g.id, ev, i))
        return "Deleted ${EV.getValue(ev.k).name} · Undo brings it back"
    }

    /** Change an entry's period and/or player. `p` is only applied when [setP] is true ("" or null = team only). */
    fun editEntry(id: String, per: String? = null, p: String? = null, setP: Boolean = false): String? {
        val g = game() ?: return null
        val e = g.events.find { it.id == id } ?: return null
        val np = if (setP && EV.getValue(e.k).ind) (if (!p.isNullOrEmpty() && player(p) != null) p else null) else e.p
        val nper = if (per != null && per in PERS) per else e.per
        if (np == e.p && nper == e.per) return null
        setGame(g.id) { gg -> gg.copy(events = gg.events.map { if (it.id == id) it.copy(per = nper, p = np) else it }) }
        push(UEdit(g.id, id, e.per, e.p))
        return if (per != null) "Moved to ${perLong(nper)}" else if (np != null) "Credited to ${pName(np)}" else "Changed to team only"
    }

    /* ---------- Games and teams ---------- */
    fun startGame(date: String, opp: String): String? {
        if (parseDay(date) == null) return "Pick the game date."
        val o = cleanName(opp, 60)
        if (o.isEmpty()) return "Enter the opponent’s name."
        val g = Game(uid(), date, o, emptyList())
        setTeam { it.copy(games = it.games + g, gameId = g.id) }
        data = data.copy(per = "1", tab = "track")
        return null
    }
    fun switchGame(id: String): Boolean {
        val g = team().games.find { it.id == id } ?: return false
        setTeam { it.copy(gameId = id) }
        data = data.copy(per = lastPer(g))
        return true
    }
    fun switchTeam(id: String): Boolean {
        if (id == data.teamId || data.teams.none { it.id == id }) return false
        data = data.copy(teamId = id)
        data = data.copy(per = lastPer(game()))
        return true
    }
    fun renameTeam(name: String, id: String = team().id): Boolean {
        val n = cleanName(name, 40)
        if (n.isEmpty() || data.teams.none { it.id == id }) return false
        data = data.copy(teams = data.teams.map { if (it.id == id) it.copy(name = n) else it })
        return true
    }
    fun addTeam(name: String): String? {
        val n = cleanName(name, 40)
        if (n.isEmpty()) return null
        val t = Team(uid(), n, emptyList(), emptyList(), null)
        data = data.copy(teams = data.teams + t, teamId = t.id, per = "1")
        return n
    }
    fun deleteTeam(): Boolean {
        if (data.teams.size < 2) return false
        val id = team().id
        val rest = data.teams.filter { it.id != id }
        data = data.copy(teams = rest, teamId = rest[0].id)
        data = data.copy(per = lastPer(game()))
        return true
    }
    /** Switch to the user's own team, or create one. Returns true when a new team was made. */
    fun myTeam(): Boolean {
        val own = data.teams.find { !it.sample }
        if (own != null) { data = data.copy(teamId = own.id); data = data.copy(per = lastPer(game())); return false }
        val t = Team(uid(), "My Team", emptyList(), emptyList(), null)
        data = data.copy(teams = data.teams + t, teamId = t.id, tab = "setup", per = "1")
        return true
    }
    fun loadSample() {
        var t = data.teams.find { it.sample }
        if (t == null) { t = sampleTeam(); data = data.copy(teams = data.teams + t) }
        data = data.copy(teamId = t.id, tab = "track")
        data = data.copy(per = lastPer(game()))
    }
    fun saveGame(id: String, date: String, opp: String): String? {
        if (parseDay(date) == null) return "Pick the game date"
        val o = cleanName(opp, 60)
        if (o.isEmpty()) return "Enter the opponent’s name"
        setGame(id) { it.copy(date = date, opp = o) }
        return null
    }
    fun deleteGame(id: String) {
        setTeam { t ->
            val games = t.games.filter { it.id != id }
            val keep = t.gameId != id && games.any { it.id == t.gameId }
            val nt = t.copy(games = games)
            nt.copy(gameId = if (keep) t.gameId else gamesNewest(nt).firstOrNull()?.id)
        }
        data = data.copy(per = lastPer(game()))
    }
    fun deleteSamples() {
        setTeam { t ->
            val nt = t.copy(games = t.games.filter { !it.sample })
            nt.copy(gameId = if (nt.games.any { it.id == t.gameId }) t.gameId else gamesNewest(nt).firstOrNull()?.id)
        }
        data = data.copy(per = lastPer(game()))
    }

    /* ---------- Roster ---------- */
    fun addPlayer(numIn: String, nameIn: String): String? {
        val name = cleanName(nameIn, 40)
        if (name.isEmpty()) return null
        val num = digits(numIn, 3)
        val t = team()
        val back = t.roster.find { it.gone && it.name.equals(name, true) && (num.isEmpty() || it.num == num) }
        if (back != null) {
            setTeam { tt -> tt.copy(roster = tt.roster.map { if (it.id == back.id) it.copy(gone = false, num = if (num.isNotEmpty()) num else it.num) else it }) }
            return "${back.name} is back on the roster"
        }
        val clash = if (num.isEmpty()) null else t.roster.find { !it.gone && it.num.isNotEmpty() && it.num.toIntOrNull() == num.toInt() }
        setTeam { it.copy(roster = it.roster + Player(uid(), num, name)) }
        return if (clash != null) "Added. Heads up: #$num is also ${clash.name}." else "Added ${if (num.isNotEmpty()) "#$num " else ""}$name"
    }
    fun pasteRoster(text: String): String {
        val parsed = parseRoster(text)
        var added = 0; var back = 0; var same = 0
        for (r in parsed.rows) {
            val roster = team().roster
            val ex = roster.find { it.name.equals(r.name, true) && (it.num == r.num || it.num.isEmpty() || r.num.isEmpty()) }
            if (ex != null) {
                if (ex.gone) back++ else same++
                setTeam { t -> t.copy(roster = t.roster.map { if (it.id == ex.id) it.copy(gone = false, num = if (r.num.isNotEmpty() && it.num.isEmpty()) r.num else it.num) else it }) }
                continue
            }
            setTeam { it.copy(roster = it.roster + Player(uid(), r.num, r.name)) }
            added++
        }
        val d = dupNums(team()).size
        return listOf(plural(added, "player") + " added", if (back > 0) "$back put back" else "", if (same > 0) "$same already on roster" else "",
            if (parsed.skipped > 0) plural(parsed.skipped, "line") + " skipped" else "", if (d > 0) "check duplicate #s" else "")
            .filter { it.isNotEmpty() }.joinToString(" · ")
    }
    fun savePlayer(id: String, numIn: String, nameIn: String): String? {
        val p = player(id) ?: return null
        val name = cleanName(nameIn, 40)
        if (name.isEmpty()) return null
        val num = digits(numIn, 3)
        val clash = if (num.isEmpty()) null else team().roster.find { it.id != p.id && !it.gone && it.num.toIntOrNull() == num.toInt() }
        setTeam { t -> t.copy(roster = t.roster.map { if (it.id == id) it.copy(num = num, name = name) else it }) }
        return if (clash != null) "Saved. Heads up: #$num is also ${clash.name}." else "Saved"
    }
    /** A player with stats is hidden (kept in reports); one without stats is deleted. */
    fun removePlayer(id: String): String? {
        val p = player(id) ?: return null
        val used = team().games.any { g -> g.events.any { it.p == id } }
        setTeam { t -> if (used) t.copy(roster = t.roster.map { if (it.id == id) it.copy(gone = true) else it }) else t.copy(roster = t.roster.filter { it.id != id }) }
        lastPick.entries.removeAll { it.value == id }
        return if (used) "${p.name} removed. Their stats stay in reports." else "${p.name} removed"
    }
    fun restorePlayer(id: String): String? {
        val p = player(id) ?: return null
        setTeam { t -> t.copy(roster = t.roster.map { if (it.id == id) it.copy(gone = false) else it }) }
        return "${p.name} is back on the roster"
    }

    /* ---------- Settings and views ---------- */
    fun setAskWho(on: Boolean) { data = data.copy(askWho = on) }
    fun setTab(tab: String) { data = data.copy(tab = tab) }
    fun setStatsView(v: String) { data = data.copy(statsView = if (v == "season") "season" else "game") }
    fun setSumPer(p: String) { if (p == "all" || p in PERS) data = data.copy(sumPer = p) }
}
