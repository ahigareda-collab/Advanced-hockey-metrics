package app.advancedmetrics.tracker.core

/**
 * A small JSON reader and writer. The app keeps its own copy so saved stats and backups from the
 * web version of the tracker read the same way here, with no extra libraries.
 */
sealed interface J
object JNull : J
data class JBool(val v: Boolean) : J
data class JNum(val v: Double) : J
data class JStr(val v: String) : J
class JArr(val v: List<J>) : J
class JObj(val v: Map<String, J>) : J {
    operator fun get(key: String): J? = v[key]
}

class JsonError(msg: String) : Exception(msg)

object Json {
    fun parse(text: String): J {
        val p = Parser(text)
        p.ws()
        val v = p.value(0)
        p.ws()
        if (p.i != text.length) throw JsonError("Extra text at ${p.i}")
        return v
    }

    fun quote(s: String): String {
        val b = StringBuilder(s.length + 2)
        b.append('"')
        for (ch in s) {
            when (ch) {
                '"' -> b.append("\\\"")
                '\\' -> b.append("\\\\")
                '\n' -> b.append("\\n")
                '\r' -> b.append("\\r")
                '\t' -> b.append("\\t")
                '\b' -> b.append("\\b")
                '\u000C' -> b.append("\\f")
                else -> if (ch < ' ' || ch == ' ' || ch == ' ') {
                    b.append("\\u").append(String.format("%04x", ch.code))
                } else b.append(ch)
            }
        }
        b.append('"')
        return b.toString()
    }

    private class Parser(val s: String) {
        var i = 0

        fun ws() {
            while (i < s.length && (s[i] == ' ' || s[i] == '\n' || s[i] == '\r' || s[i] == '\t')) i++
        }

        fun value(depth: Int): J {
            if (depth > 200) throw JsonError("Too deeply nested")
            if (i >= s.length) throw JsonError("Unexpected end")
            return when (val c = s[i]) {
                '{' -> obj(depth)
                '[' -> arr(depth)
                '"' -> JStr(str())
                't' -> lit("true", JBool(true))
                'f' -> lit("false", JBool(false))
                'n' -> lit("null", JNull)
                else -> if (c == '-' || c in '0'..'9') num() else throw JsonError("Unexpected '$c' at $i")
            }
        }

        fun lit(word: String, v: J): J {
            if (!s.startsWith(word, i)) throw JsonError("Bad literal at $i")
            i += word.length
            return v
        }

        fun num(): J {
            val start = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] == '.' || s[i] == 'e' || s[i] == 'E' || s[i] == '+' || s[i] == '-')) i++
            val d = s.substring(start, i).toDoubleOrNull() ?: throw JsonError("Bad number at $start")
            return JNum(d)
        }

        fun str(): String {
            i++ // opening quote
            val b = StringBuilder()
            while (true) {
                if (i >= s.length) throw JsonError("Unterminated string")
                val c = s[i++]
                when {
                    c == '"' -> return b.toString()
                    c == '\\' -> {
                        if (i >= s.length) throw JsonError("Bad escape")
                        when (val e = s[i++]) {
                            '"' -> b.append('"'); '\\' -> b.append('\\'); '/' -> b.append('/')
                            'b' -> b.append('\b'); 'f' -> b.append('\u000C'); 'n' -> b.append('\n')
                            'r' -> b.append('\r'); 't' -> b.append('\t')
                            'u' -> {
                                if (i + 4 > s.length) throw JsonError("Bad unicode escape")
                                // Exactly four hex digits (toIntOrNull alone would also take a sign, like "-041").
                                val code = s.substring(i, i + 4).takeIf { h -> h.all { it in '0'..'9' || it in 'a'..'f' || it in 'A'..'F' } }
                                    ?.toInt(16) ?: throw JsonError("Bad unicode escape")
                                b.append(code.toChar()); i += 4
                            }
                            else -> throw JsonError("Bad escape \\$e")
                        }
                    }
                    else -> b.append(c)
                }
            }
        }

        fun arr(depth: Int): J {
            i++
            val out = ArrayList<J>()
            ws()
            if (i < s.length && s[i] == ']') { i++; return JArr(out) }
            while (true) {
                ws(); out.add(value(depth + 1)); ws()
                if (i >= s.length) throw JsonError("Unterminated array")
                when (s[i++]) {
                    ',' -> continue
                    ']' -> return JArr(out)
                    else -> throw JsonError("Expected , or ] at ${i - 1}")
                }
            }
        }

        fun obj(depth: Int): J {
            i++
            val out = LinkedHashMap<String, J>()
            ws()
            if (i < s.length && s[i] == '}') { i++; return JObj(out) }
            while (true) {
                ws()
                if (i >= s.length || s[i] != '"') throw JsonError("Expected a key at $i")
                val k = str()
                ws()
                if (i >= s.length || s[i] != ':') throw JsonError("Expected : at $i")
                i++
                ws()
                out[k] = value(depth + 1)
                ws()
                if (i >= s.length) throw JsonError("Unterminated object")
                when (s[i++]) {
                    ',' -> continue
                    '}' -> return JObj(out)
                    else -> throw JsonError("Expected , or } at ${i - 1}")
                }
            }
        }
    }
}

// Lenient readers used when loading saved data and backups.
fun J?.str(): String? = (this as? JStr)?.v
fun J?.arr(): List<J>? = (this as? JArr)?.v
fun J?.obj(): JObj? = this as? JObj
fun J?.truthy(): Boolean = when (this) {
    null, JNull -> false
    is JBool -> v
    is JNum -> v != 0.0 && !v.isNaN()
    is JStr -> v.isNotEmpty()
    else -> true
}
/** Text form of a value the way the web version saw it (numbers like 9 become "9"). */
fun J?.text(): String? = when (this) {
    is JStr -> v
    is JNum -> if (v == Math.floor(v) && !v.isInfinite() && kotlin.math.abs(v) < 1e15) v.toLong().toString() else v.toString()
    is JBool -> v.toString()
    else -> null
}
