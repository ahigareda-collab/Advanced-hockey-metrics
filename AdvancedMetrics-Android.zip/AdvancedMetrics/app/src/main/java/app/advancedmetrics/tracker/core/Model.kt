package app.advancedmetrics.tracker.core

import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import kotlin.random.Random

/* ---------- What gets tracked ---------- */

enum class Tone { NONE, GOOD, BAD }
enum class Line { RED, BLUE, GOAL }

/** One stat button. `ind` = it can be credited to a player. */
data class EvType(val key: String, val name: String, val lbl: String, val ind: Boolean, val tone: Tone)

val EV: Map<String, EvType> = linkedMapOf(
    "FOW" to EvType("FOW", "Faceoff won", "Won", true, Tone.GOOD),
    "FOL" to EvType("FOL", "Faceoff lost", "Lost", true, Tone.BAD),
    "ENC" to EvType("ENC", "Controlled entry", "Controlled", false, Tone.GOOD),
    "ENU" to EvType("ENU", "Dump / chip entry", "Dump / chip", false, Tone.NONE),
    "EXC" to EvType("EXC", "Controlled exit", "Controlled", false, Tone.GOOD),
    "EXU" to EvType("EXU", "Clear / chip exit", "Clear / chip", false, Tone.NONE),
    "TOO" to EvType("TOO", "O-zone turnover", "O-zone", true, Tone.BAD),
    "TON" to EvType("TON", "Neutral-zone turnover", "Neutral", true, Tone.BAD),
    "TOD" to EvType("TOD", "D-zone turnover", "D-zone", true, Tone.BAD),
    "PPF" to EvType("PPF", "PP goal for", "Goal for", false, Tone.GOOD),
    "PPA" to EvType("PPA", "PP goal against", "Goal against", false, Tone.BAD),
    "OTS" to EvType("OTS", "One-timer shot", "One-timer", false, Tone.NONE),
    "BBW" to EvType("BBW", "Board battle won", "Battle won", true, Tone.GOOD)
)

val PERS = listOf("1", "2", "3", "OT")

data class Group(val id: String, val title: String, val line: Line, val keys: List<String>, val pp: Boolean = false)

val GROUPS = listOf(
    Group("fo", "Faceoffs", Line.RED, listOf("FOW", "FOL")),
    Group("en", "Zone entries", Line.BLUE, listOf("ENC", "ENU")),
    Group("ex", "Zone exits", Line.BLUE, listOf("EXC", "EXU")),
    Group("to", "Turnovers", Line.RED, listOf("TOO", "TON", "TOD")),
    Group("sb", "Shots & battles", Line.GOAL, listOf("OTS", "BBW")),
    Group("pp", "Power play", Line.GOAL, listOf("PPF", "PPA"), pp = true)
)

/** The small line under each group's title on the board. */
fun groupMeta(id: String, c: Map<String, Int>): String {
    fun n(k: String) = c[k] ?: 0
    return when (id) {
        "fo" -> pct(n("FOW"), n("FOW") + n("FOL"))?.let { "$it% won" } ?: ""
        "en" -> pct(n("ENC"), n("ENC") + n("ENU"))?.let { "$it% ctrl" } ?: ""
        "ex" -> pct(n("EXC"), n("EXC") + n("EXU"))?.let { "$it% ctrl" } ?: ""
        "to" -> (n("TOO") + n("TON") + n("TOD")).let { if (it > 0) "$it total" else "" }
        "pp" -> if (n("PPF") + n("PPA") > 0) "Diff " + signed(n("PPF") - n("PPA")) else ""
        else -> ""
    }
}

/* ---------- Saved data (same shape as the web tracker, so backups move both ways) ---------- */

data class Player(val id: String, val num: String, val name: String, val gone: Boolean = false)
data class Ev(val id: String, val k: String, val p: String?, val per: String, val ts: Long)
data class Game(val id: String, val date: String, val opp: String, val events: List<Ev>, val sample: Boolean = false)
data class Team(
    val id: String, val name: String, val roster: List<Player>, val games: List<Game>,
    val gameId: String?, val sample: Boolean = false
)
data class AppData(
    val teams: List<Team>, val teamId: String, val per: String = "1", val sumPer: String = "all",
    val askWho: Boolean = true, val tab: String = "track", val statsView: String = "game"
)

/** The team being tracked, and the game it's tracking. */
fun AppData.team(): Team = teams.find { it.id == teamId } ?: teams[0]
fun AppData.game(): Game? = team().let { t -> t.games.find { it.id == t.gameId } }

/* ---------- Small helpers ---------- */

fun pct(a: Int, b: Int): Int? = if (b > 0) Math.round(100.0 * a / b).toInt() else null
fun pctS(a: Int, b: Int): String = pct(a, b)?.let { "$it%" } ?: "—"
fun signed(n: Int) = if (n > 0) "+$n" else "$n"
fun plural(n: Int, one: String, many: String = one + "s") = "$n ${if (n == 1) one else many}"
/** "hi" / "lo" / "" against good and poor thresholds, used to color rates. */
fun toneOf(a: Int, b: Int, hi: Int, lo: Int): String {
    val p = pct(a, b) ?: return ""
    return if (p >= hi) "hi" else if (p < lo) "lo" else ""
}
fun perShort(p: String) = if (p == "OT") "OT" else "P$p"
fun perLong(p: String) = if (p == "OT") "Overtime" else "Period $p"

private val idChars = "abcdefghijklmnopqrstuvwxyz0123456789"
fun uid(): String {
    val r = (1..7).map { idChars[Random.nextInt(idChars.length)] }.joinToString("")
    val t = java.lang.Long.toString(System.currentTimeMillis(), 36).takeLast(3)
    return r + t
}
private val SAFE_ID = Regex("^[A-Za-z0-9_-]{1,40}$")
fun safeId(x: String?): String = if (x != null && SAFE_ID.matches(x) && x !in setOf("__proto__", "constructor", "prototype", "_team")) x else ""

fun today(): String = LocalDate.now().toString()
private val DAY = Regex("^(\\d{4})-(\\d{2})-(\\d{2})$")
fun parseDay(s: String?): LocalDate? {
    val m = DAY.matchEntire(s ?: return null) ?: return null
    return try { LocalDate.of(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt()) } catch (e: Exception) { null }
}

fun cleanName(v: String?, n: Int): String = (v ?: "").take(n * 2).replace(Regex("\\s+"), " ").trim().take(n)
fun digits(v: String?, n: Int): String = (v ?: "").filter { it in '0'..'9' }.take(n)

fun numKey(p: Player): Int = p.num.toIntOrNull() ?: 999
val byNum: Comparator<Player> = compareBy<Player> { numKey(it) }.thenBy { it.name.lowercase() }

/** Newest game first; games on the same day keep the order they were added (newest first). */
fun gamesNewest(t: Team): List<Game> = t.games.withIndex()
    .sortedWith(compareByDescending<IndexedValue<Game>> { it.value.date }.thenByDescending { it.index })
    .map { it.value }
fun gamesOldest(t: Team): List<Game> = gamesNewest(t).reversed()
fun lastPer(g: Game?): String = g?.events?.lastOrNull()?.per ?: "1"

/* ---------- Loading: damaged parts are skipped or repaired instead of refusing everything ---------- */

class Loaded(val data: AppData, val fixed: Int)

fun normalize(root: J): Loaded? {
    val d = root.obj() ?: return null
    val teamsIn = d["teams"].arr() ?: return null
    var fixed = 0
    fun newId(used: MutableSet<String>): String { var id: String; do { id = uid() } while (id in used); used.add(id); return id }
    fun fresh(want: String?, used: MutableSet<String>): String {
        val id = safeId(want)
        if (id.isNotEmpty() && used.add(id)) return id
        fixed++
        return newId(used)
    }
    // When two items share an id, links keep pointing at the first one, as the web tracker's lookups do.
    val tids = HashSet<String>()
    val tmap = HashMap<String, String>()
    val teams = ArrayList<Team>()
    for (tj in teamsIn) {
        val t = tj.obj()
        if (t == null) { fixed++; continue }
        val tid = fresh(t["id"].str(), tids)
        t["id"].str()?.let { tmap.putIfAbsent(it, tid) }

        val pids = HashSet<String>()
        val pmap = HashMap<String, String>()
        val roster = ArrayList<Player>()
        for (pj in t["roster"].arr() ?: emptyList()) {
            val p = pj.obj()
            if (p == null) { fixed++; continue }
            val pid = fresh(p["id"].str(), pids)
            p["id"].str()?.let { pmap.putIfAbsent(it, pid) }
            roster.add(Player(pid, (p["num"].text() ?: "").take(4).trim(), cleanName(p["name"].text(), 80).ifEmpty { "Player" }, p["gone"].truthy()))
        }

        val gids = HashSet<String>()
        val gmap = HashMap<String, String>()
        val games = ArrayList<Game>()
        for (gj in t["games"].arr() ?: emptyList()) {
            val g = gj.obj()
            if (g == null) { fixed++; continue }
            val gid = fresh(g["id"].str(), gids)
            g["id"].str()?.let { gmap.putIfAbsent(it, gid) }
            var date = g["date"].str()?.take(10) ?: ""
            if (parseDay(date) == null) { fixed++; date = today() }
            val eids = HashSet<String>()
            val events = ArrayList<Ev>()
            for (ej in g["events"].arr() ?: emptyList()) {
                val e = ej.obj()
                val k = e?.get("k").str()
                if (e == null || k == null || k !in EV) { fixed++; continue }
                var per = e["per"].text() ?: ""
                if (per !in PERS) { fixed++; per = "1" }
                var p: String? = null
                val want = e["p"].str()
                if (EV.getValue(k).ind && !want.isNullOrEmpty()) {
                    p = pmap[want]
                    if (p == null) {   // a stat for someone missing from the roster keeps its own "Removed player" row
                        fixed++
                        val ph = Player(newId(pids), "", "Removed player", true)
                        roster.add(ph); pmap[want] = ph.id; p = ph.id
                    }
                }
                val ts = (e["ts"] as? JNum)?.v?.takeIf { it.isFinite() }?.toLong() ?: 0L
                events.add(Ev(fresh(e["id"].str(), eids), k, p, per, ts))
            }
            games.add(Game(gid, date, cleanName(g["opp"].text(), 80).ifEmpty { "Opponent" }, events, g["sample"].truthy()))
        }
        val name = cleanName(t["name"].text(), 80).ifEmpty { "Team" }
        var team = Team(tid, name, roster, games, null)
        team = team.copy(gameId = gmap[t["gameId"].str() ?: ""] ?: gamesNewest(team).firstOrNull()?.id)
        // The starter team from the first version counts as sample only while it holds nothing but sample games.
        val sample = t["sample"] == JBool(true) || (name == "Sample Team" && games.isNotEmpty() && games.all { it.sample })
        teams.add(team.copy(sample = sample))
    }
    if (teams.isEmpty()) return null
    val tab = when (d["tab"].str()) { "stats", "game", "season" -> "stats"; "setup", "roster" -> "setup"; else -> "track" }
    val sv = if (d["statsView"].str() == "season" || d["tab"].str() == "season") "season" else "game"
    val per = d["per"].text().takeIf { it in PERS } ?: "1"
    val sumPer = d["sumPer"].text().takeIf { it == "all" || it in PERS } ?: "all"
    val data = AppData(teams, tmap[d["teamId"].str() ?: ""] ?: teams[0].id, per, sumPer, d["askWho"] != JBool(false), tab, sv)
    return Loaded(data, fixed)
}

/** Files saved by some editors (Windows Notepad) start with a byte-order mark, which isn't part of the JSON. */
fun parseSaved(text: String): Loaded? = try { normalize(Json.parse(text.removePrefix("\uFEFF"))) } catch (e: Exception) { null }

fun toJson(d: AppData): String {
    val b = StringBuilder()
    fun q(s: String?) = if (s == null) "null" else Json.quote(s)
    b.append("{\"teams\":[")
    d.teams.forEachIndexed { ti, t ->
        if (ti > 0) b.append(',')
        b.append("{\"id\":").append(q(t.id)).append(",\"name\":").append(q(t.name))
        if (t.sample) b.append(",\"sample\":true")
        b.append(",\"roster\":[")
        t.roster.forEachIndexed { i, p ->
            if (i > 0) b.append(',')
            b.append("{\"id\":").append(q(p.id)).append(",\"num\":").append(q(p.num)).append(",\"name\":").append(q(p.name))
            if (p.gone) b.append(",\"gone\":true")
            b.append('}')
        }
        b.append("],\"games\":[")
        t.games.forEachIndexed { i, g ->
            if (i > 0) b.append(',')
            b.append("{\"id\":").append(q(g.id)).append(",\"date\":").append(q(g.date)).append(",\"opp\":").append(q(g.opp))
            if (g.sample) b.append(",\"sample\":true")
            b.append(",\"events\":[")
            g.events.forEachIndexed { j, e ->
                if (j > 0) b.append(',')
                b.append("{\"id\":").append(q(e.id)).append(",\"k\":").append(q(e.k)).append(",\"p\":").append(q(e.p))
                    .append(",\"per\":").append(q(e.per)).append(",\"ts\":").append(e.ts).append('}')
            }
            b.append("]}")
        }
        b.append("],\"gameId\":").append(q(t.gameId)).append('}')
    }
    b.append("],\"teamId\":").append(q(d.teamId)).append(",\"per\":").append(q(d.per)).append(",\"sumPer\":").append(q(d.sumPer))
        .append(",\"tab\":").append(q(d.tab)).append(",\"statsView\":").append(q(d.statsView))
        .append(",\"askWho\":").append(d.askWho).append(",\"activeP\":null}")
    return b.toString()
}

/* ---------- Sample team ---------- */

private class Lcg(var s: Long) {
    fun next(): Double { s = (s * 1664525L + 1013904223L) and 0xFFFFFFFFL; return s / 4294967296.0 }
}

fun sampleTeam(): Team {
    val r = Lcg(7)
    val roster = listOf(4 to "Alvarez", 7 to "Brennan", 9 to "Costa", 11 to "Dwyer", 13 to "Ferris", 17 to "Gallo", 19 to "Hughes",
        21 to "Kowalski", 22 to "Marsh", 27 to "Nolan", 44 to "Okafor", 31 to "Pryor").map { Player(uid(), it.first.toString(), it.second) }
    val centers = listOf(roster[2], roster[5], roster[7])
    val skaters = roster.subList(0, 11)
    fun pick(a: List<Player>) = a[(r.next() * a.size).toInt().coerceAtMost(a.size - 1)]
    val plan = listOf(Triple("FOW", 14, centers), Triple("FOL", 11, centers), Triple("ENC", 17, null), Triple("ENU", 12, null),
        Triple("EXC", 21, null), Triple("EXU", 9, null), Triple("TOO", 6, skaters), Triple("TON", 5, skaters), Triple("TOD", 4, skaters),
        Triple("PPF", 2, null), Triple("PPA", 1, null), Triple("OTS", 8, null), Triple("BBW", 16, skaters))
    val day = LocalDate.now().minusDays(7)
    val start = LocalDateTime.of(day.year, day.month, day.dayOfMonth, 19, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
    val raw = ArrayList<Pair<Ev, Double>>()
    for ((k, n, pool) in plan) repeat(n) {
        val p = pool?.let { pick(it).id }
        val per = PERS[(r.next() * 3).toInt().coerceAtMost(2)]
        raw.add(Ev(uid(), k, p, per, 0) to r.next())
    }
    val events = raw.sortedWith(compareBy<Pair<Ev, Double>> { PERS.indexOf(it.first.per) }.thenBy { it.second })
        .mapIndexed { i, x -> x.first.copy(ts = start + i * 32000L) }
    val g = Game(uid(), day.toString(), "Sample opponent", events, sample = true)
    return Team(uid(), "Sample Team", roster, listOf(g), g.id, sample = true)
}

fun seedData(): AppData {
    val t = sampleTeam()
    return AppData(listOf(t), t.id, per = lastPer(t.games.first()))
}
