package app.advancedmetrics.tracker.core

/** Reads a pasted roster: "9 Mike Costa", "9, Costa, Mike", spreadsheet rows with or without a header. */
data class RosterLine(val num: String, val name: String)
class RosterParse(val rows: List<RosterLine>, val skipped: Int)

private val POSRE = Regex("^(f|d|g|c|lw|rw|w|fwd|def|forwards?|defen[cs]e(m[ae]n)?|goalie|goaltender|goalkeeper|cent(er|re)|wing(er)?)$", RegexOption.IGNORE_CASE)
private val YEAR = Regex("^(19|20)\\d{2}$")
private val DATEISH = Regex("^\\d{1,4}[/\\-.]\\d{1,2}[/\\-.]\\d{1,4}$")
private val NUM3 = Regex("^\\d{1,3}$")
private val HASHNUM = Regex("^#?\\d{1,3}$")
private val LETTER = Regex("\\p{L}")
private val HEADER_LINE = Regex("^(#|no\\.?|num(ber)?|jersey)\\s+(player\\s+)?name\\b", RegexOption.IGNORE_CASE)

fun csvSplit(line: String): List<String> {
    val out = ArrayList<String>(); val cur = StringBuilder(); var q = false
    var i = 0
    while (i < line.length) {
        val ch = line[i]
        if (q) {
            if (ch == '"') {
                if (i + 1 < line.length && line[i + 1] == '"') { cur.append('"'); i++ } else q = false
            } else cur.append(ch)
        } else if (ch == '"' && cur.isBlank()) { cur.setLength(0); q = true }
        else if (ch == ',') { out.add(cur.toString()); cur.setLength(0) }
        else cur.append(ch)
        i++
    }
    out.add(cur.toString())
    return out
}

fun flipName(n: String): String =
    if (Regex("^[^,]+,\\s*[^,]+$").matches(n)) n.split(Regex(",\\s*")).reversed().joinToString(" ") else n

private fun headerMap(cells: List<String>): Map<String, Int>? {
    val map = LinkedHashMap<String, Int>()
    val tests = listOf(
        "first" to Regex("\\bfirst\\b|\\bgiven\\b"), "last" to Regex("\\blast\\b|\\bsurname\\b|\\bfamily\\b"),
        "num" to Regex("#|^no\\.?$|\\bnum(ber)?\\b|\\bjersey\\b"), "name" to Regex("\\bname\\b|^players?$|^athlete$"))
    cells.forEachIndexed { i, raw ->
        val c = raw.trim().lowercase()
        if (c.isEmpty()) return@forEachIndexed
        if (c.all { it in '0'..'9' }) return null
        for ((k, re) in tests) if (k !in map && re.containsMatchIn(c)) { map[k] = i; break }
    }
    return if ("name" in map || "first" in map || "last" in map) map else null
}

fun parseRoster(text: String): RosterParse {
    val lines = text.split(Regex("\\r?\\n")).map { it.trim() }.filter { it.isNotEmpty() }
    val rows = ArrayList<RosterLine>()
    var map: Map<String, Int>? = null
    var skipped = 0
    lines.forEachIndexed { i, line ->
        val tabbed = '\t' in line
        val comma = !tabbed && ',' in line
        val semi = !tabbed && !comma && ';' in line
        val split = tabbed || comma || semi
        val cells = when {
            tabbed -> line.split('\t')
            comma -> csvSplit(line)
            semi -> line.split(';')
            else -> line.split(Regex("\\s+"))
        }.map { it.trim() }
        if (i == 0) {
            if (split) { map = headerMap(cells); if (map != null) return@forEachIndexed }
            if (!split && HEADER_LINE.containsMatchIn(line)) return@forEachIndexed
        }
        var num = ""; var name: String
        val m = map
        if (m != null) {
            fun g(k: String) = m[k]?.let { cells.getOrNull(it)?.trim() } ?: ""
            num = g("num").removePrefix("#")
            name = if (g("name").isNotEmpty()) flipName(g("name")) else listOf(g("first"), g("last")).filter { it.isNotEmpty() }.joinToString(" ")
        } else if (split) {
            val rest = ArrayList<String>()
            for (c in cells) {
                if (c.isEmpty()) continue
                val v = c.removePrefix("#")
                if (num.isEmpty() && NUM3.matches(v)) { num = v; continue }
                if (YEAR.matches(v) || DATEISH.matches(v) || POSRE.matches(v)) continue
                rest.add(c)
            }
            // "Costa, Mike" (two single words split by a comma) is Last, First.
            name = if (comma && rest.size == 2 && rest.none { ' ' in it }) rest[1] + " " + rest[0] else rest.joinToString(" ") { flipName(it) }
        } else {
            val tk = cells.toMutableList()
            if (tk.size > 1 && HASHNUM.matches(tk[0])) num = tk.removeAt(0).replace("#", "")
            else if (tk.size > 1 && HASHNUM.matches(tk.last())) num = tk.removeAt(tk.size - 1).replace("#", "")
            while (tk.size > 1 && (POSRE.matches(tk.last()) || YEAR.matches(tk.last()))) tk.removeAt(tk.size - 1)
            name = tk.joinToString(" ")
        }
        num = digits(num, 3); name = cleanName(name, 40)
        if (name.isNotEmpty() && LETTER.containsMatchIn(name)) rows.add(RosterLine(num, name)) else skipped++
    }
    return RosterParse(rows, skipped)
}
