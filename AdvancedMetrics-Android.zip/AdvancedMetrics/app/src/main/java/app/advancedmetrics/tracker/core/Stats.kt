package app.advancedmetrics.tracker.core

import java.time.format.DateTimeFormatter
import java.util.Locale

/* ---------- Counting ---------- */

/** Faceoffs, battles and turnovers credited to one player (or to the team when nobody was picked). */
class PStat {
    var FOW = 0; var FOL = 0; var BBW = 0; var TOO = 0; var TON = 0; var TOD = 0
    val TO get() = TOO + TON + TOD
    val games = HashSet<String>()
    fun add(k: String) {
        when (k) { "FOW" -> FOW++; "FOL" -> FOL++; "BBW" -> BBW++; "TOO" -> TOO++; "TON" -> TON++; "TOD" -> TOD++ }
    }
}

class Tally(val c: Map<String, Int>, val players: Map<String, PStat>) {
    operator fun get(k: String): Int = c[k] ?: 0
}

const val TEAM_KEY = "_team"

fun tally(events: List<Ev>, per: String = "all"): Tally {
    val c = LinkedHashMap<String, Int>()
    EV.keys.forEach { c[it] = 0 }
    val p = LinkedHashMap<String, PStat>()
    for (e in events) {
        if (per != "all" && e.per != per) continue
        c[e.k] = (c[e.k] ?: 0) + 1
        if (EV[e.k]?.ind == true) p.getOrPut(e.p ?: TEAM_KEY) { PStat() }.add(e.k)
    }
    return Tally(c, p)
}

fun seasonPlayers(t: Team): Map<String, PStat> {
    val p = LinkedHashMap<String, PStat>()
    for (g in t.games) for (e in g.events) {
        if (EV[e.k]?.ind != true) continue
        val s = p.getOrPut(e.p ?: TEAM_KEY) { PStat() }
        s.add(e.k); s.games.add(g.id)
    }
    return p
}

class IndRow(val id: String, val num: String, val name: String, val s: PStat) {
    val games get() = s.games.size
}

/** Players in jersey order, anyone no longer on the roster after them, then the team row last. */
fun indRows(t: Team, p: Map<String, PStat>): List<IndRow> {
    val ids = ArrayList<String>()
    t.roster.sortedWith(byNum).forEach { if (p.containsKey(it.id)) ids.add(it.id) }
    p.keys.forEach { if (it != TEAM_KEY && it !in ids) ids.add(it) }
    if (p.containsKey(TEAM_KEY)) ids.add(TEAM_KEY)
    return ids.map { id ->
        val pl = if (id == TEAM_KEY) null else t.roster.find { it.id == id }
        val name = when {
            id == TEAM_KEY -> "Team (no player)"
            pl == null -> "Removed player"
            pl.gone && pl.name != "Removed player" -> pl.name + " (removed)"
            else -> pl.name
        }
        IndRow(id, pl?.num ?: "", name, p.getValue(id))
    }
}

fun playerCounts(t: Team): Map<String, Int> {
    val n = HashMap<String, Int>()
    t.games.forEach { g -> g.events.forEach { e -> e.p?.let { n[it] = (n[it] ?: 0) + 1 } } }
    return n
}

fun dupNums(t: Team): Set<String> {
    val c = HashMap<String, Int>(); val d = HashSet<String>()
    t.roster.forEach { p ->
        if (p.gone || p.num.isEmpty()) return@forEach
        val k = p.num.toIntOrNull()?.toString() ?: return@forEach
        c[k] = (c[k] ?: 0) + 1
        if (c.getValue(k) > 1) d.add(k)
    }
    return d
}
fun isDup(d: Set<String>, p: Player) = p.num.isNotEmpty() && p.num.toIntOrNull()?.toString() in d

/* ---------- Tables ---------- */

class Rate(val a: Int, val b: Int, val hi: Int, val lo: Int)
sealed interface MetricRow
class Sec(val title: String) : MetricRow
class Metric(val label: String, val count: String, val rate: Rate? = null) : MetricRow

fun teamRows(c: Tally): List<MetricRow> {
    val to = c["TOO"] + c["TON"] + c["TOD"]; val en = c["ENC"] + c["ENU"]; val ex = c["EXC"] + c["EXU"]
    return listOf(
        Sec("Faceoffs"),
        Metric("Faceoffs won", "${c["FOW"]}"), Metric("Faceoffs lost", "${c["FOL"]}"),
        Metric("Faceoff %", "${c["FOW"]}–${c["FOL"]}", Rate(c["FOW"], c["FOW"] + c["FOL"], 52, 48)),
        Sec("Special teams"),
        Metric("PP goals for", "${c["PPF"]}"), Metric("PP goals against", "${c["PPA"]}"),
        Sec("Turnovers"),
        Metric("O-zone turnovers", "${c["TOO"]}"), Metric("Neutral-zone turnovers", "${c["TON"]}"),
        Metric("D-zone turnovers", "${c["TOD"]}"), Metric("Total turnovers", "$to"),
        Sec("Transition"),
        Metric("Controlled entries / total", "${c["ENC"]} / $en", Rate(c["ENC"], en, 55, 45)),
        Metric("Controlled exits / total", "${c["EXC"]} / $ex", Rate(c["EXC"], ex, 65, 50)),
        Sec("Shots & battles"),
        Metric("One-timer shots", "${c["OTS"]}"), Metric("Board battles won", "${c["BBW"]}")
    )
}

val SCOLS = listOf("Date", "Opponent", "FO W", "FO L", "FO %", "PPGF", "PPGA", "OZ TO", "NZ TO", "DZ TO", "Ctrl entries", "Total entries",
    "Entry %", "Ctrl exits", "Total exits", "Exit %", "One-timers", "Board battles won")

fun seasonRow(c: Tally): List<String> = listOf(
    "${c["FOW"]}", "${c["FOL"]}", pctS(c["FOW"], c["FOW"] + c["FOL"]), "${c["PPF"]}", "${c["PPA"]}", "${c["TOO"]}", "${c["TON"]}", "${c["TOD"]}",
    "${c["ENC"]}", "${c["ENC"] + c["ENU"]}", pctS(c["ENC"], c["ENC"] + c["ENU"]), "${c["EXC"]}", "${c["EXC"] + c["EXU"]}",
    pctS(c["EXC"], c["EXC"] + c["EXU"]), "${c["OTS"]}", "${c["BBW"]}")

fun seasonTally(t: Team): Tally = tally(gamesOldest(t).flatMap { it.events })

/* ---------- Dates ---------- */

private fun fmt(s: String, pattern: String): String {
    val d = parseDay(s) ?: return s
    return d.format(DateTimeFormatter.ofPattern(pattern, Locale.getDefault()))
}
fun fmtShort(s: String) = fmt(s, "MMM d")
fun fmtDay(s: String) = fmt(s, "EEE, MMM d")
fun fmtLong(s: String) = fmt(s, "EEE, MMM d, yyyy")
fun fmtYear(s: String) = fmt(s, "MMM d, yyyy")
fun fmtWeekday(s: String) = fmt(s, "EEEE")
fun fmtMonth(s: String) = fmt(s, "MMM")
fun fmtDayNum(s: String) = parseDay(s)?.dayOfMonth?.toString() ?: ""
fun gLabel(g: Game) = "${fmtShort(g.date)} vs ${g.opp}"

fun seasonSpan(gs: List<Game>): String {
    if (gs.isEmpty()) return ""
    val a = gs.first().date; val b = gs.last().date
    if (gs.size == 1 || a == b) return fmtYear(a)
    return if (a.take(4) == b.take(4)) "${fmtShort(a)} – ${fmtYear(b)}" else "${fmtYear(a)} – ${fmtYear(b)}"
}

/* ---------- Copy-to-clipboard tables (tab separated, pastes into Excel or Sheets) ---------- */

fun gameTsv(t: Team, g: Game, per: String): String {
    val c = tally(g.events, per)
    val l = ArrayList<List<Any>>()
    l.add(listOf(t.name)); l.add(listOf(gLabel(g) + if (per == "all") "" else " – " + perLong(per))); l.add(emptyList())
    l.add(listOf("Team metric", "Count", "Rate"))
    teamRows(c).forEach { if (it is Metric) l.add(listOf(it.label, it.count, it.rate?.let { r -> pctS(r.a, r.b) } ?: "")) }
    l.add(emptyList()); l.add(listOf("#", "Player", "FO W", "FO L", "FO %", "Board battles won", "Turnovers"))
    indRows(t, c.players).forEach { r -> l.add(listOf(r.num, r.name, r.s.FOW, r.s.FOL, pctS(r.s.FOW, r.s.FOW + r.s.FOL), r.s.BBW, r.s.TO)) }
    return l.joinToString("\n") { it.joinToString("\t") }
}

fun seasonTsv(t: Team): String {
    val gs = gamesOldest(t)
    val l = ArrayList<List<Any>>()
    l.add(listOf("${t.name} – season")); l.add(emptyList()); l.add(SCOLS)
    gs.forEach { g -> l.add(listOf(g.date, g.opp + if (g.sample) " (sample)" else "") + seasonRow(tally(g.events))) }
    l.add(listOf("Totals", plural(gs.size, "game")) + seasonRow(seasonTally(t)))
    l.add(emptyList()); l.add(listOf("#", "Player", "GP", "FO W", "FO L", "FO %", "Board battles won", "Turnovers"))
    indRows(t, seasonPlayers(t)).forEach { r -> l.add(listOf(r.num, r.name, r.games, r.s.FOW, r.s.FOL, pctS(r.s.FOW, r.s.FOW + r.s.FOL), r.s.BBW, r.s.TO)) }
    return l.joinToString("\n") { it.joinToString("\t") }
}
