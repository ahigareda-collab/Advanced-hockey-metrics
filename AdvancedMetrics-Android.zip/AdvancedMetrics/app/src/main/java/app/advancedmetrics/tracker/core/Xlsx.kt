package app.advancedmetrics.tracker.core

import java.io.ByteArrayOutputStream
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * A small .xlsx writer: styled sheets, frozen header rows and live formulas. Each formula also stores
 * its worked-out value, so phone previews that don't calculate still show the numbers.
 */
class XCell(val v: Any? = null, val f: String? = null, val s: Int = 0)
class XSheet(
    val name: String, val rows: List<List<XCell?>>, val freeze: Int = 0, val titleRow: Int = 0, val landscape: Boolean = false,
    val widths: List<Double> = emptyList(), val heights: Map<Int, Double> = emptyMap(), val merges: List<String> = emptyList()
)

data class XStyle(
    val b: Boolean = false, val sz: Int = 10, val color: String = "", val fill: String = "", val top: Pair<String, String>? = null,
    val bottom: Pair<String, String>? = null, val h: String = "", val va: String = "", val wrap: Boolean = false, val fmt: Int = 0
)

class XStyles {
    private val fonts = mutableListOf("<font><sz val=\"10\"/><name val=\"Arial\"/></font>")
    private val fills = mutableListOf("<fill><patternFill patternType=\"none\"/></fill>", "<fill><patternFill patternType=\"gray125\"/></fill>")
    private val borders = mutableListOf("<border><left/><right/><top/><bottom/><diagonal/></border>")
    private val xfs = mutableListOf("<xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\" xfId=\"0\"/>")
    private fun idx(list: MutableList<String>, s: String): Int { val i = list.indexOf(s); if (i >= 0) return i; list.add(s); return list.size - 1 }
    private fun edge(tag: String, b: Pair<String, String>?) = if (b == null) "<$tag/>" else "<$tag style=\"${b.first}\"><color rgb=\"FF${b.second}\"/></$tag>"

    fun get(o: XStyle): Int {
        val fo = idx(fonts, "<font>${if (o.b) "<b/>" else ""}<sz val=\"${o.sz}\"/>${if (o.color.isNotEmpty()) "<color rgb=\"FF${o.color}\"/>" else ""}<name val=\"Arial\"/></font>")
        val fi = if (o.fill.isNotEmpty()) idx(fills, "<fill><patternFill patternType=\"solid\"><fgColor rgb=\"FF${o.fill}\"/><bgColor indexed=\"64\"/></patternFill></fill>") else 0
        val bo = if (o.top != null || o.bottom != null) idx(borders, "<border><left/><right/>${edge("top", o.top)}${edge("bottom", o.bottom)}<diagonal/></border>") else 0
        val al = if (o.h.isNotEmpty() || o.va.isNotEmpty() || o.wrap)
            "<alignment${if (o.h.isNotEmpty()) " horizontal=\"${o.h}\"" else ""}${if (o.va.isNotEmpty()) " vertical=\"${o.va}\"" else ""}${if (o.wrap) " wrapText=\"1\"" else ""}/>" else ""
        val attrs = "numFmtId=\"${o.fmt}\" fontId=\"$fo\" fillId=\"$fi\" borderId=\"$bo\" xfId=\"0\"" +
            (if (fo > 0) " applyFont=\"1\"" else "") + (if (fi > 0) " applyFill=\"1\"" else "") + (if (bo > 0) " applyBorder=\"1\"" else "") +
            (if (o.fmt > 0) " applyNumberFormat=\"1\"" else "")
        return idx(xfs, if (al.isNotEmpty()) "<xf $attrs applyAlignment=\"1\">$al</xf>" else "<xf $attrs/>")
    }

    fun xml(ns: String) = "<styleSheet xmlns=\"$ns\"><numFmts count=\"1\"><numFmt numFmtId=\"165\" formatCode=\"mmm d, yyyy\"/></numFmts>" +
        "<fonts count=\"${fonts.size}\">${fonts.joinToString("")}</fonts><fills count=\"${fills.size}\">${fills.joinToString("")}</fills>" +
        "<borders count=\"${borders.size}\">${borders.joinToString("")}</borders><cellStyleXfs count=\"1\"><xf numFmtId=\"0\" fontId=\"0\" fillId=\"0\" borderId=\"0\"/></cellStyleXfs>" +
        "<cellXfs count=\"${xfs.size}\">${xfs.joinToString("")}</cellXfs><cellStyles count=\"1\"><cellStyle name=\"Normal\" xfId=\"0\" builtinId=\"0\"/></cellStyles></styleSheet>"
}

object Xlsx {
    private const val NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
    private const val R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
    private const val PR = "http://schemas.openxmlformats.org/package/2006/relationships"
    private const val HEAD = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n"

    fun esc(s: String): String {
        val b = StringBuilder()
        for (ch in s) {
            val c = ch.code
            if ((c < 0x20 && c != 0x09 && c != 0x0A && c != 0x0D) || c == 0xFFFE || c == 0xFFFF) continue
            when (ch) { '&' -> b.append("&amp;"); '<' -> b.append("&lt;"); '>' -> b.append("&gt;"); '"' -> b.append("&quot;"); else -> b.append(ch) }
        }
        return b.toString()
    }
    fun col(i0: Int): String { var i = i0 + 1; val s = StringBuilder(); while (i > 0) { s.insert(0, ('A' + (i - 1) % 26)); i = (i - 1) / 26 }; return s.toString() }

    private fun num(v: Double): String = if (v == Math.floor(v) && !v.isInfinite() && Math.abs(v) < 1e15) v.toLong().toString() else v.toString()

    private fun cellXml(c: XCell, ref: String): String {
        val st = if (c.s != 0) " s=\"${c.s}\"" else ""
        val v = c.v
        val n = (v as? Number)?.toDouble()?.takeIf { it.isFinite() }
        if (c.f != null) {
            return if (n != null) "<c r=\"$ref\"$st><f>${esc(c.f)}</f><v>${num(n)}</v></c>"
            else "<c r=\"$ref\"$st t=\"str\"><f>${esc(c.f)}</f><v>${esc(v?.toString() ?: "")}</v></c>"
        }
        if (v == null || v == "") return if (st.isNotEmpty()) "<c r=\"$ref\"$st/>" else ""
        if (n != null) return "<c r=\"$ref\"$st><v>${num(n)}</v></c>"
        return "<c r=\"$ref\"$st t=\"inlineStr\"><is><t xml:space=\"preserve\">${esc(v.toString())}</t></is></c>"
    }

    private fun sheetXml(s: XSheet, selected: Boolean): String {
        val fr = s.freeze
        val view = "<sheetViews><sheetView workbookViewId=\"0\"${if (selected) " tabSelected=\"1\"" else ""}>" +
            (if (fr > 0) "<pane ySplit=\"$fr\" topLeftCell=\"A${fr + 1}\" activePane=\"bottomLeft\" state=\"frozen\"/><selection pane=\"bottomLeft\" activeCell=\"A${fr + 1}\" sqref=\"A${fr + 1}\"/>" else "") +
            "</sheetView></sheetViews>"
        val cols = if (s.widths.isNotEmpty()) "<cols>" + s.widths.mapIndexed { i, w -> "<col min=\"${i + 1}\" max=\"${i + 1}\" width=\"$w\" customWidth=\"1\"/>" }.joinToString("") + "</cols>" else ""
        val rows = StringBuilder()
        s.rows.forEachIndexed { r, row ->
            val ht = s.heights[r]?.let { " ht=\"$it\" customHeight=\"1\"" } ?: ""
            rows.append("<row r=\"${r + 1}\"$ht>")
            row.forEachIndexed { i, c -> if (c != null) rows.append(cellXml(c, col(i) + (r + 1))) }
            rows.append("</row>")
        }
        val merges = if (s.merges.isNotEmpty()) "<mergeCells count=\"${s.merges.size}\">" + s.merges.joinToString("") { "<mergeCell ref=\"$it\"/>" } + "</mergeCells>" else ""
        return "<worksheet xmlns=\"$NS\" xmlns:r=\"$R\"><sheetPr><pageSetUpPr fitToPage=\"1\"/></sheetPr>$view<sheetFormatPr defaultRowHeight=\"15\"/>$cols<sheetData>$rows</sheetData>$merges" +
            "<pageMargins left=\"0.4\" right=\"0.4\" top=\"0.5\" bottom=\"0.5\" header=\"0.3\" footer=\"0.3\"/><pageSetup orientation=\"${if (s.landscape) "landscape" else "portrait"}\" fitToWidth=\"1\" fitToHeight=\"0\"/></worksheet>"
    }

    fun build(sheets: List<XSheet>, st: XStyles): ByteArray {
        val names = ArrayList<String>(); val seen = HashSet<String>()
        for (s in sheets) {
            var n = s.name.replace(Regex("[\\[\\]:*?/\\\\]"), "").take(31).ifEmpty { "Sheet" }
            var k = 2
            while (n.lowercase() in seen) n = n.take(28) + " " + k++
            seen.add(n.lowercase()); names.add(n)
        }
        val defs = sheets.mapIndexed { i, s ->
            if (s.titleRow > 0) "<definedName name=\"_xlnm.Print_Titles\" localSheetId=\"$i\">'${esc(names[i].replace("'", "''"))}'!$${s.titleRow}:$${s.titleRow}</definedName>" else ""
        }.joinToString("")
        val files = linkedMapOf(
            "[Content_Types].xml" to HEAD + "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/styles.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml\"/>" +
                sheets.indices.joinToString("") { "<Override PartName=\"/xl/worksheets/sheet${it + 1}.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/>" } + "</Types>",
            "_rels/.rels" to HEAD + "<Relationships xmlns=\"$PR\"><Relationship Id=\"rId1\" Type=\"$R/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>",
            "xl/workbook.xml" to HEAD + "<workbook xmlns=\"$NS\" xmlns:r=\"$R\"><bookViews><workbookView activeTab=\"0\"/></bookViews><sheets>" +
                names.mapIndexed { i, n -> "<sheet name=\"${esc(n)}\" sheetId=\"${i + 1}\" r:id=\"rId${i + 1}\"/>" }.joinToString("") + "</sheets>" +
                (if (defs.isNotEmpty()) "<definedNames>$defs</definedNames>" else "") + "<calcPr calcId=\"191029\" fullCalcOnLoad=\"1\"/></workbook>",
            "xl/_rels/workbook.xml.rels" to HEAD + "<Relationships xmlns=\"$PR\">" +
                sheets.indices.joinToString("") { "<Relationship Id=\"rId${it + 1}\" Type=\"$R/worksheet\" Target=\"worksheets/sheet${it + 1}.xml\"/>" } +
                "<Relationship Id=\"rId${sheets.size + 1}\" Type=\"$R/styles\" Target=\"styles.xml\"/></Relationships>"
        )
        sheets.forEachIndexed { i, s -> files["xl/worksheets/sheet${i + 1}.xml"] = HEAD + sheetXml(s, i == 0) }
        files["xl/styles.xml"] = HEAD + st.xml(NS)
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { z ->
            for ((name, data) in files) { z.putNextEntry(ZipEntry(name)); z.write(data.toByteArray(Charsets.UTF_8)); z.closeEntry() }
        }
        return out.toByteArray()
    }
}

/* ---------- The tracker's workbook: game by period, game players, season, season players ---------- */

fun buildWorkbook(t: Team, vg: Game?): ByteArray {
    val st = XStyles(); val C = Xlsx::col
    val INK = "0E1924"; val RED = "C8102E"; val ICE = "EDF2F6"; val LINE = "D3DCE4"; val GRAY = "546372"; val OKC = "2B7A4B"; val WHITE = "FFFFFF"
    val T = st.get(XStyle(b = true, sz = 16, color = INK, va = "center")); val SUB = st.get(XStyle(color = GRAY)); val NOTE = st.get(XStyle(color = GRAY, sz = 9))
    fun H(h: String = "center") = st.get(XStyle(b = true, color = WHITE, fill = INK, h = h, va = "center", wrap = true, bottom = "thick" to RED))
    val SEC = st.get(XStyle(b = true, color = GRAY, fill = ICE, sz = 9))
    fun cell(o: XStyle) = st.get(o.copy(va = "center", bottom = "thin" to LINE))
    val L = cell(XStyle(h = "left")); val LB = cell(XStyle(h = "left", b = true)); val N = cell(XStyle(h = "center")); val NB = cell(XStyle(h = "center", b = true))
    val JN = cell(XStyle(h = "center", b = true, color = RED)); val DATE = cell(XStyle(h = "left", fmt = 165))
    fun tc(v: Any?, hi: Int, lo: Int): String = if (v !is Double) GRAY else if (v * 100 >= hi) OKC else if (v * 100 < lo) RED else INK
    fun P(v: Any?, hi: Int, lo: Int) = cell(XStyle(h = "center", b = true, fmt = 9, color = tc(v, hi, lo)))
    fun TOT(o: XStyle = XStyle()) = st.get(o.copy(b = true, fill = ICE, va = "center", h = if (o.h.isEmpty()) "center" else o.h, top = "medium" to INK))
    fun TOTP(v: Any?, hi: Int, lo: Int) = TOT(XStyle(fmt = 9, color = tc(v, hi, lo)))
    fun ratio(a: Int, b: Int): Any = if (a + b > 0) a.toDouble() / (a + b) else ""
    fun pf(a: String, b: String) = "IF($a+$b=0,\"\",$a/($a+$b))"
    fun numOrText(s: String): Any = if (Regex("^(0|[1-9]\\d*)$").matches(s)) s.toInt() else s
    fun excelDate(s: String): Any = parseDay(s)?.let { ChronoUnit.DAYS.between(LocalDate.of(1899, 12, 30), it).toDouble() } ?: s
    val sheets = ArrayList<XSheet>()

    if (vg != null) {
        val per = PERS.map { tally(vg.events, it) }; val all = tally(vg.events); val cs = per + all
        val rows = ArrayList<List<XCell?>>()
        rows.add(listOf(XCell("${t.name} vs ${vg.opp}", s = T))); rows.add(listOf(XCell(fmtLong(vg.date) + if (vg.sample) " · sample game" else "", s = SUB))); rows.add(emptyList())
        rows.add(listOf("Metric", "P1", "P2", "P3", "OT", "Game").mapIndexed { i, h -> XCell(h, s = H(if (i > 0) "center" else "left")) })
        val vals = HashMap<Int, List<Int>>()
        fun rn() = rows.size + 1
        fun count(label: String, k: String): Int {
            val r = rn()
            rows.add(listOf(XCell(label, s = L)) + per.map { XCell(it[k], s = N) } + XCell(all[k], "SUM(B$r:E$r)", NB))
            vals[r] = cs.map { it[k] }; return r
        }
        fun total(label: String, rs: List<Int>): Int {
            val r = rn(); val v = cs.indices.map { i -> rs.sumOf { vals.getValue(it)[i] } }; vals[r] = v
            rows.add(listOf(XCell(label, s = LB)) + v.mapIndexed { i, n -> XCell(n, rs.joinToString("+") { C(i + 1) + it }, NB) }); return r
        }
        fun rate(label: String, a: Int, b: Int, hi: Int, lo: Int) {
            rows.add(listOf(XCell(label, s = LB)) + cs.indices.map { i -> val v = ratio(vals.getValue(a)[i], vals.getValue(b)[i]); XCell(v, pf(C(i + 1) + a, C(i + 1) + b), P(v, hi, lo)) })
        }
        fun sec(label: String) { rows.add(listOf(XCell(label.uppercase(), s = SEC)) + List(5) { XCell("", s = SEC) }) }
        sec("Faceoffs"); val fw = count("Faceoffs won", "FOW"); val fl = count("Faceoffs lost", "FOL"); rate("Faceoff %", fw, fl, 52, 48)
        sec("Zone entries"); val ec = count("Controlled entries", "ENC"); val eu = count("Dump / chip entries", "ENU"); total("Total entries", listOf(ec, eu)); rate("Controlled entry %", ec, eu, 55, 45)
        sec("Zone exits"); val xc = count("Controlled exits", "EXC"); val xu = count("Clear / chip exits", "EXU"); total("Total exits", listOf(xc, xu)); rate("Controlled exit %", xc, xu, 65, 50)
        sec("Turnovers"); val t1 = count("O-zone turnovers", "TOO"); val t2 = count("Neutral-zone turnovers", "TON"); val t3 = count("D-zone turnovers", "TOD"); total("Total turnovers", listOf(t1, t2, t3))
        sec("Power play"); count("PP goals for", "PPF"); count("PP goals against", "PPA")
        sec("Shots & battles"); count("One-timer shots", "OTS"); count("Board battles won", "BBW")
        sheets.add(XSheet("Game", rows, 4, 4, widths = listOf(28.0, 9.0, 9.0, 9.0, 9.0, 10.0), heights = mapOf(0 to 26.0, 3 to 22.0)))

        val head = listOf("#", "Player", "FO won", "FO lost", "FO %", "Board battles won", "O-zone TO", "Neutral TO", "D-zone TO", "Turnovers")
        val pr = ArrayList<List<XCell?>>()
        pr.add(listOf(XCell("${t.name} vs ${vg.opp} · players", s = T))); pr.add(listOf(XCell(fmtLong(vg.date), s = SUB))); pr.add(emptyList())
        pr.add(head.mapIndexed { i, h -> XCell(h, s = H(if (i == 1) "left" else "center")) })
        val ir = indRows(t, all.players)
        ir.forEach { x -> val r = pr.size + 1; val fo = ratio(x.s.FOW, x.s.FOL)
            pr.add(listOf(XCell(numOrText(x.num), s = JN), XCell(x.name, s = LB), XCell(x.s.FOW, s = N), XCell(x.s.FOL, s = N), XCell(fo, pf("C$r", "D$r"), P(fo, 52, 48)),
                XCell(x.s.BBW, s = N), XCell(x.s.TOO, s = N), XCell(x.s.TON, s = N), XCell(x.s.TOD, s = N), XCell(x.s.TO, "SUM(G$r:I$r)", NB))) }
        if (ir.isEmpty()) pr.add(listOf(XCell("No player stats logged in this game.", s = NOTE)))
        sheets.add(XSheet("Game players", pr, 4, 4, widths = listOf(6.0, 24.0, 9.0, 9.0, 9.0, 12.0, 10.0, 10.0, 10.0, 11.0), heights = mapOf(0 to 26.0, 3 to 30.0)))
    }

    val gs = gamesOldest(t)
    val sh = listOf("Date", "Opponent", "FO won", "FO lost", "FO %", "Ctrl entries", "Dump / chip entries", "Ctrl entry %", "Ctrl exits", "Clear / chip exits",
        "Ctrl exit %", "O-zone TO", "Neutral TO", "D-zone TO", "Turnovers", "PP goals for", "PP goals against", "One-timers", "Board battles won")
    val keys = listOf(null, null, "FOW", "FOL", null, "ENC", "ENU", null, "EXC", "EXU", null, "TOO", "TON", "TOD", null, "PPF", "PPA", "OTS", "BBW")
    val sr = ArrayList<List<XCell?>>()
    sr.add(listOf(XCell("${t.name} season", s = T))); sr.add(listOf(XCell(if (gs.isNotEmpty()) "${plural(gs.size, "game")} · ${seasonSpan(gs)}" else "No games yet", s = SUB))); sr.add(emptyList())
    sr.add(sh.mapIndexed { i, h -> XCell(h, s = H(if (i < 2) "left" else "center")) })
    val first = sr.size + 1
    val sum = HashMap<String, Int>()
    gs.forEach { g ->
        val c = tally(g.events); val r = sr.size + 1
        keys.forEach { k -> if (k != null) sum[k] = (sum[k] ?: 0) + c[k] }
        val fo = ratio(c["FOW"], c["FOL"]); val en = ratio(c["ENC"], c["ENU"]); val ex = ratio(c["EXC"], c["EXU"])
        sr.add(listOf(XCell(excelDate(g.date), s = DATE), XCell(g.opp + if (g.sample) " (sample)" else "", s = L), XCell(c["FOW"], s = N), XCell(c["FOL"], s = N),
            XCell(fo, pf("C$r", "D$r"), P(fo, 52, 48)), XCell(c["ENC"], s = N), XCell(c["ENU"], s = N), XCell(en, pf("F$r", "G$r"), P(en, 55, 45)),
            XCell(c["EXC"], s = N), XCell(c["EXU"], s = N), XCell(ex, pf("I$r", "J$r"), P(ex, 65, 50)),
            XCell(c["TOO"], s = N), XCell(c["TON"], s = N), XCell(c["TOD"], s = N), XCell(c["TOO"] + c["TON"] + c["TOD"], "SUM(L$r:N$r)", NB),
            XCell(c["PPF"], s = N), XCell(c["PPA"], s = N), XCell(c["OTS"], s = N), XCell(c["BBW"], s = N)))
    }
    if (gs.isNotEmpty()) {
        val r = sr.size + 1; val last = r - 1
        fun s2(k: String) = sum[k] ?: 0
        val fo = ratio(s2("FOW"), s2("FOL")); val en = ratio(s2("ENC"), s2("ENU")); val ex = ratio(s2("EXC"), s2("EXU"))
        sr.add(sh.indices.map { i ->
            val l1 = C(i)
            when (i) {
                0 -> XCell("Totals", s = TOT(XStyle(h = "left")))
                1 -> XCell(plural(gs.size, "game"), s = TOT(XStyle(h = "left")))
                4 -> XCell(fo, pf("C$r", "D$r"), TOTP(fo, 52, 48))
                7 -> XCell(en, pf("F$r", "G$r"), TOTP(en, 55, 45))
                10 -> XCell(ex, pf("I$r", "J$r"), TOTP(ex, 65, 50))
                14 -> XCell(s2("TOO") + s2("TON") + s2("TOD"), "SUM(L$r:N$r)", TOT())
                else -> XCell(s2(keys[i]!!), "SUM($l1$first:$l1$last)", TOT())
            }
        })
    } else sr.add(listOf(XCell("Track a game to fill this sheet.", s = NOTE)))
    sheets.add(XSheet("Season", sr, 4, 4, landscape = true, widths = listOf(13.0, 22.0, 8.0, 8.0, 8.0, 9.0, 10.0, 9.0, 9.0, 10.0, 9.0, 9.0, 9.0, 9.0, 10.0, 8.0, 9.0, 9.0, 10.0), heights = mapOf(0 to 26.0, 3 to 30.0)))

    val ph = listOf("#", "Player", "Games", "FO won", "FO lost", "FO %", "Board battles won", "O-zone TO", "Neutral TO", "D-zone TO", "Turnovers")
    val pp = ArrayList<List<XCell?>>()
    pp.add(listOf(XCell("${t.name} season · players", s = T))); pp.add(listOf(XCell("Faceoffs, board battles and turnovers credited to each player", s = SUB))); pp.add(emptyList())
    pp.add(ph.mapIndexed { i, h -> XCell(h, s = H(if (i == 1) "left" else "center")) })
    val spr = indRows(t, seasonPlayers(t))
    spr.forEach { x -> val r = pp.size + 1; val fo = ratio(x.s.FOW, x.s.FOL)
        pp.add(listOf(XCell(numOrText(x.num), s = JN), XCell(x.name, s = LB), XCell(x.games, s = N), XCell(x.s.FOW, s = N), XCell(x.s.FOL, s = N), XCell(fo, pf("D$r", "E$r"), P(fo, 52, 48)),
            XCell(x.s.BBW, s = N), XCell(x.s.TOO, s = N), XCell(x.s.TON, s = N), XCell(x.s.TOD, s = N), XCell(x.s.TO, "SUM(H$r:J$r)", NB))) }
    if (spr.isEmpty()) pp.add(listOf(XCell("No player stats logged yet.", s = NOTE)))
    sheets.add(XSheet("Season players", pp, 4, 4, widths = listOf(6.0, 24.0, 8.0, 9.0, 9.0, 9.0, 12.0, 10.0, 10.0, 10.0, 11.0), heights = mapOf(0 to 26.0, 3 to 30.0)))
    return Xlsx.build(sheets, st)
}
