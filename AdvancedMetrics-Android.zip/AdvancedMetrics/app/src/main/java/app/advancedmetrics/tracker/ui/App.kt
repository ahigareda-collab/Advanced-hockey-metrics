package app.advancedmetrics.tracker.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.advancedmetrics.tracker.core.*

/** Page width and side gutter shared by every block on every tab. */
fun Modifier.gut(): Modifier = this.widthIn(max = 720.dp).fillMaxWidth().padding(horizontal = 16.dp)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun App(vm: AppViewModel) {
    val r = LocalRink.current
    val d = vm.data
    val ctx = LocalContext.current
    val snack = remember { SnackbarHostState() }
    val list = rememberLazyListState()

    LaunchedEffect(vm.message) {
        val m = vm.message ?: return@LaunchedEffect
        snack.currentSnackbarData?.dismiss()
        snack.showSnackbar(m.text, duration = if (m.long) SnackbarDuration.Long else SnackbarDuration.Short)
    }
    LaunchedEffect(d.tab) { list.scrollToItem(0) }
    BackHandler(enabled = d.tab != "track") { vm.setTab("track") }

    // Saving files: the phone asks where to put each one (Downloads, Drive, ...).
    val saveXlsx = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(MIME_XLSX)) { vm.finishExport(it, ctx.contentResolver) }
    val savePdf = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(MIME_PDF)) { vm.finishExport(it, ctx.contentResolver) }
    val saveJson = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(MIME_JSON)) { vm.finishExport(it, ctx.contentResolver) }
    val openBackup = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { vm.readBackupFile(it, ctx.contentResolver) }
    LaunchedEffect(vm.pendingExport) {
        val f = vm.pendingExport ?: return@LaunchedEffect
        if (vm.exportLaunched) return@LaunchedEffect
        vm.exportLaunched = true
        try {
            when (f.mime) { MIME_XLSX -> saveXlsx.launch(f.name); MIME_PDF -> savePdf.launch(f.name); else -> saveJson.launch(f.name) }
        } catch (e: Exception) {
            vm.finishExport(null, ctx.contentResolver)
            vm.say("This phone has no app for saving files")
        }
    }
    val pickBackup = {
        try { openBackup.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }
        catch (e: Exception) { vm.say("This phone has no app for opening files") }
    }

    Scaffold(
        containerColor = r.ice,
        snackbarHost = {
            SnackbarHost(snack) { Snackbar(it, containerColor = r.ink, contentColor = r.surface, shape = RoundedCornerShape(14.dp)) }
        }
    ) { pad ->
        val dir = LocalLayoutDirection.current
        LazyColumn(
            state = list,
            modifier = Modifier.fillMaxSize().padding(top = pad.calculateTopPadding(), start = pad.calculateStartPadding(dir), end = pad.calculateEndPadding(dir)),
            contentPadding = PaddingValues(top = 10.dp, bottom = pad.calculateBottomPadding() + 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item(key = "mast") { Masthead(vm, d) }
            item(key = "tabs") { Tabs(vm, d) }
            when (d.tab) {
                "stats" -> statsScreen(vm, d)
                "setup" -> setupScreen(vm, d)
                else -> trackScreen(vm, d)
            }
        }
    }
    SheetHost(vm, pickBackup)
}

@Composable
private fun Masthead(vm: AppViewModel, d: AppData) {
    val r = LocalRink.current
    val t = vm.team(); val g = vm.game()
    Column(Modifier.gut(), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Lbl("Advanced metrics", Modifier.weight(1f))
            val (txt, dot) = when {
                !vm.saveOk -> "Not saving" to r.red
                g == null -> "No game" to r.ink2
                else -> "${g.events.size} logged" to r.ok
            }
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(r.surface).border(1.dp, if (vm.saveOk) r.line else r.red, RoundedCornerShape(50))
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)
            ) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(dot))
                Text(txt.uppercase(), style = Type.label(if (vm.saveOk) r.ink2 else r.red, 10.5.sp))
            }
        }
        Text(t.name.uppercase(), style = Type.display(44.sp, r.ink, 0.sp), maxLines = 2, overflow = TextOverflow.Ellipsis, lineHeight = 44.sp)
        Row(
            Modifier.padding(top = 4.dp).clip(RoundedCornerShape(12.dp)).background(r.surface).border(1.dp, r.line, RoundedCornerShape(12.dp))
                .clickable(role = Role.Button) { vm.openSheet(Sheet.Games(g == null)) }
                .semantics { contentDescription = if (g != null) "Tracking ${gLabel(g)}. Choose or start a game" else "No game yet. Start a game" }
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(if (g != null) "VS ${g.opp.uppercase()}" else "NO GAME YET", style = Type.display(19.sp, r.red), maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
            if (g != null) Text(fmtDay(g.date), style = Type.body(r.ink2, 14.sp, FontWeight.SemiBold), maxLines = 1)
            if (g?.sample == true) SampleTag()
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (g != null) "GAMES" else "START ONE", style = Type.label(r.ink2))
                Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, tint = r.ink2, modifier = Modifier.size(16.dp))
            }
        }
    }
}

@Composable
private fun Tabs(vm: AppViewModel, d: AppData) {
    val r = LocalRink.current
    val n = vm.engine.activeRoster().size
    Row(
        Modifier.gut().clip(RoundedCornerShape(14.dp)).background(r.surface).border(1.dp, r.line, RoundedCornerShape(14.dp)).padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        listOf("track" to "Track", "stats" to "Stats", "setup" to "Setup").forEach { (id, label) ->
            val on = d.tab == id
            Row(
                Modifier.weight(1f).heightIn(min = 44.dp).clip(RoundedCornerShape(10.dp)).background(if (on) r.ink else Color.Transparent)
                    .clickable(role = Role.Tab) { vm.setTab(id) }.semantics { selected = on },
                horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically
            ) {
                Text(label, style = Type.body(if (on) r.surface else r.ink2, 15.sp, FontWeight.Bold))
                if (id == "setup") Count(n, onDark = on)
            }
        }
    }
}
