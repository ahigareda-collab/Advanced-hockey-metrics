package app.advancedmetrics.tracker.ui

import android.app.Application
import android.content.ContentResolver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import app.advancedmetrics.tracker.core.*
import java.io.File
import java.text.Normalizer
import java.util.concurrent.Executors

/** What the bottom sheet is showing. */
sealed interface Sheet {
    data class Who(val k: String) : Sheet
    object Log : Sheet
    data class Entry(val id: String) : Sheet
    data class Games(val focusNew: Boolean) : Sheet
    data class PlayerEdit(val id: String) : Sheet
    data class GameEdit(val id: String) : Sheet
    data class Confirm(val title: String, val message: String, val actions: List<Action>) : Sheet
    object Restore : Sheet
}
class Action(val label: String, val danger: Boolean = false, val keepOpen: Boolean = false, val run: () -> Unit)
data class Msg(val id: Long, val text: String, val long: Boolean = false)
class ExportFile(val name: String, val mime: String, val bytes: ByteArray)

const val MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
const val MIME_PDF = "application/pdf"
const val MIME_JSON = "application/json"

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val file = File(app.filesDir, "metrics.json")
    private val io = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    val engine: Engine
    var data by mutableStateOf(seedData()); private set
    var sheet by mutableStateOf<Sheet?>(null); private set
    var message by mutableStateOf<Msg?>(null); private set
    var saveOk by mutableStateOf(true); private set
    /** Game shown on the Stats tab; null = the game being tracked. */
    var viewGameId by mutableStateOf<String?>(null)
    /** File waiting for the user to pick where to save it. */
    var pendingExport by mutableStateOf<ExportFile?>(null); private set
    /** The save screen for [pendingExport] is already open (so a screen rotation doesn't open a second one). */
    var exportLaunched = false

    private var lastTapKey = ""; private var lastTapAt = 0L; private var boardBlockUntil = 0L; private var sheetOpenedAt = 0L
    private var msgId = 0L

    init {
        var start: AppData? = null
        if (file.exists()) {
            val text = runCatching { file.readText() }.getOrNull()
            val loaded = text?.let { parseSaved(it) }
            if (loaded != null) {
                start = loaded.data
                if (loaded.fixed > 0 && text != null) runCatching { val keep = File(file.parentFile, "metrics-before-repair.json"); if (!keep.exists()) keep.writeText(text) }
            } else {
                runCatching { file.copyTo(File(file.parentFile, "metrics-unreadable.json"), overwrite = true) }
                say("Saved stats couldn’t be read, so the tracker started fresh. The old data was set aside, not deleted.", long = true)
            }
        }
        engine = Engine(start ?: seedData())
        data = engine.data
    }

    /* ---------- Plumbing ---------- */
    fun say(text: String, long: Boolean = false) { message = Msg(++msgId, text, long) }

    private fun commit(msg: String? = null, long: Boolean = false) {
        data = engine.data
        val json = toJson(engine.data)
        io.execute {
            val ok = runCatching {
                val tmp = File(file.parentFile, "metrics.json.tmp")
                tmp.writeText(json)
                if (!tmp.renameTo(file)) { file.writeText(json); tmp.delete() }
            }.isSuccess
            main.post {
                if (ok != saveOk) {
                    saveOk = ok
                    if (!ok) say("Your stats aren’t saving. Save a backup in Setup before you close the app.", long = true)
                }
            }
        }
        if (msg != null) say(msg, long)
    }

    fun team() = engine.team()
    fun game() = engine.game()
    fun viewGame(): Game? = engine.team().games.find { it.id == viewGameId } ?: engine.game()

    fun openSheet(s: Sheet) { if (sheet == null) sheetOpenedAt = SystemClock.uptimeMillis(); sheet = s }
    fun closeSheet(cancelled: Boolean = false) {
        val was = sheet
        sheet = null
        if (was is Sheet.Who) {
            boardBlockUntil = SystemClock.uptimeMillis() + 350   // a bounce after picking a player can't land on the board
            if (cancelled) say("Nothing logged")
        }
    }

    /* ---------- Tracking ---------- */
    /** Returns true when the tap was accepted (for the button flash and buzz). */
    fun tapStat(k: String): Boolean {
        if (engine.game() == null) { openSheet(Sheet.Games(true)); return false }
        val now = SystemClock.uptimeMillis()
        if (now < boardBlockUntil) return false
        if (lastTapKey == k && now - lastTapAt < 400) return false   // an accidental double tap
        lastTapKey = k; lastTapAt = now
        if (EV.getValue(k).ind && engine.askingWho()) openSheet(Sheet.Who(k)) else log(k, null)
        return true
    }
    fun pickWho(pid: String?) {
        val s = sheet as? Sheet.Who ?: return
        if (SystemClock.uptimeMillis() - sheetOpenedAt < 300) return   // the second half of a double tap landing on the sheet
        closeSheet()
        log(s.k, pid)
    }
    private fun log(k: String, pid: String?) {
        val ev = engine.logEvent(k, pid) ?: return
        commit(engine.logMessage(ev))
    }
    fun setPeriod(p: String) { if (engine.setPeriod(p)) commit("Now logging ${perLong(p)}") }
    fun undo() { val m = engine.undo() ?: return; commit(m) }
    fun deleteEntry(id: String) {
        val m = engine.deleteEntry(id) ?: return
        commit(m)
        if (sheet is Sheet.Entry) sheet = Sheet.Log
    }
    fun editEntryPer(id: String, per: String) { engine.editEntry(id, per = per)?.let { commit(it) } }
    fun editEntryWho(id: String, pid: String?) { engine.editEntry(id, p = pid, setP = true)?.let { commit(it) } }
    /** Older games the user chose to keep logging to without the reminder. */
    var keptOld by mutableStateOf(setOf<String>()); private set
    fun keepOld(gid: String) { keptOld = keptOld + gid }

    /* ---------- Games and teams ---------- */
    fun startGame(date: String, opp: String): String? {
        val err = engine.startGame(date, opp)
        if (err != null) return err
        viewGameId = null
        closeSheet()
        commit("Game started vs ${engine.game()!!.opp} · Period 1")
        return null
    }
    fun switchGame(id: String) {
        if (!engine.switchGame(id)) return
        viewGameId = null
        closeSheet()
        commit("Tracking " + gLabel(engine.game()!!))
    }
    fun trackGame(id: String) { engine.setTab("track"); switchGame(id) }
    fun switchTeam(id: String) { if (engine.switchTeam(id)) { viewGameId = null; commit("Switched to ${engine.team().name}") } }
    fun renameTeam(id: String, name: String): Boolean { if (!engine.renameTeam(name, id)) return false; commit(); return true }
    fun addTeam(name: String): Boolean {
        val n = engine.addTeam(name) ?: return false
        viewGameId = null
        commit("$n added. Add its roster below.", long = true); return true
    }
    fun askDeleteTeam() {
        if (data.teams.size < 2) return
        val t = engine.team(); val ev = t.games.sumOf { it.events.size }
        openSheet(Sheet.Confirm("Delete team?", "Delete ${t.name} with ${plural(t.roster.count { !it.gone }, "player")}, ${plural(t.games.size, "game")} and ${plural(ev, "logged stat")}? This can’t be undone.",
            listOf(Action("Delete team", danger = true) { engine.deleteTeam(); viewGameId = null; commit("${t.name} deleted") })))
    }
    fun myTeam() {
        val created = engine.myTeam(); viewGameId = null
        commit(if (created) "Name your team, then add your roster." else "Switched to ${engine.team().name}", long = created)
    }
    fun loadSample() { engine.loadSample(); viewGameId = null; commit("Sample team loaded. Delete it in Setup when you’re done.", long = true) }
    fun saveGame(id: String, date: String, opp: String): String? {
        val err = engine.saveGame(id, date, opp); if (err != null) return err
        closeSheet(); commit("Game saved"); return null
    }
    fun askDeleteGame(id: String) {
        val g = engine.team().games.find { it.id == id } ?: return
        sheet = Sheet.Confirm("Delete game?", "Delete ${gLabel(g)} and its ${plural(g.events.size, "logged stat")}? This can’t be undone.",
            listOf(Action("Delete game", danger = true) { engine.deleteGame(id); if (viewGameId == id) viewGameId = null; commit("Game deleted") }))
    }
    fun askDeleteSamples() {
        val n = engine.team().games.count { it.sample }; if (n == 0) return
        openSheet(Sheet.Confirm(if (n > 1) "Delete sample games?" else "Delete sample game?",
            "Remove ${if (n > 1) "the $n sample games" else "the sample game"} from ${engine.team().name} so only your real games count?",
            listOf(Action(if (n > 1) "Delete sample games" else "Delete sample game", danger = true) { engine.deleteSamples(); viewGameId = null; commit("Sample removed") })))
    }

    /* ---------- Roster ---------- */
    fun addPlayer(num: String, name: String): Boolean { val m = engine.addPlayer(num, name) ?: return false; commit(m, long = true); return true }
    fun pasteRoster(text: String) { commit(engine.pasteRoster(text), long = true) }
    fun savePlayer(id: String, num: String, name: String): Boolean {
        val m = engine.savePlayer(id, num, name) ?: return false
        closeSheet(); commit(m, long = m.length > 6); return true
    }
    fun removePlayer(id: String) { val m = engine.removePlayer(id) ?: return; closeSheet(); commit(m) }
    fun restorePlayer(id: String) { engine.restorePlayer(id)?.let { commit(it) } }

    /* ---------- Settings and views ---------- */
    fun setAskWho(on: Boolean) { engine.setAskWho(on); commit(if (on) "Player credit is on" else "Player credit is off") }
    fun setTab(t: String) { engine.setTab(t); commit() }
    fun setStatsView(v: String) { engine.setStatsView(v); commit() }
    fun setSumPer(p: String) { engine.setSumPer(p); commit() }
    fun openGameStats(id: String) { viewGameId = id; engine.setStatsView("game"); engine.setSumPer("all"); commit() }

    /* ---------- Files ---------- */
    private fun fname(parts: List<String>, ext: String): String =
        Normalizer.normalize(parts.filter { it.isNotEmpty() }.joinToString(" "), Normalizer.Form.NFD).replace(Regex("\\p{M}"), "")
            .replace(Regex("[^\\w\\- ]+"), "").trim().replace(Regex("\\s+"), "-") + "." + ext

    fun exportExcel() {
        val t = engine.team()
        if (t.games.isEmpty()) { say("Track a game first"); return }
        val bytes = runCatching { buildWorkbook(t, viewGame()) }.getOrElse { say("Couldn’t build the Excel file"); return }
        exportLaunched = false; pendingExport = ExportFile(fname(listOf(t.name, "stats", today()), "xlsx"), MIME_XLSX, bytes)
    }
    fun exportPdf() {
        val t = engine.team()
        val bytes: ByteArray; val name: String
        if (data.statsView == "season") {
            if (t.games.isEmpty()) { say("No games to report yet"); return }
            bytes = runCatching { PdfReport.season(t) }.getOrElse { say("Couldn’t build the PDF"); return }
            name = fname(listOf(t.name, "season", gamesOldest(t).last().date), "pdf")
        } else {
            val g = viewGame() ?: run { say("Start a game first"); return }
            bytes = runCatching { PdfReport.game(t, g, data.sumPer) }.getOrElse { say("Couldn’t build the PDF"); return }
            name = fname(listOf(t.name, g.date, "vs", g.opp, if (data.sumPer == "all") "" else perLong(data.sumPer)), "pdf")
        }
        exportLaunched = false; pendingExport = ExportFile(name, MIME_PDF, bytes)
    }
    fun exportBackup() {
        exportLaunched = false; pendingExport = ExportFile(fname(listOf("Advanced Metrics backup", today()), "json"), MIME_JSON, toJson(engine.data).toByteArray())
    }
    fun backupText(): String = toJson(engine.data)
    fun copyText(): String = if (data.statsView == "season") seasonTsv(engine.team()) else viewGame()?.let { gameTsv(engine.team(), it, data.sumPer) } ?: ""

    /** Called with where the user chose to save the pending file (null = they backed out). */
    fun finishExport(uri: Uri?, resolver: ContentResolver) {
        val f = pendingExport ?: return
        pendingExport = null
        exportLaunched = false
        if (uri == null) return
        val ok = runCatching { resolver.openOutputStream(uri, "wt")!!.use { it.write(f.bytes) } }.isSuccess
        say(if (ok) "Saved ${f.name}" else "Couldn’t save the file there")
    }

    fun readBackupFile(uri: Uri?, resolver: ContentResolver) {
        if (uri == null) return
        val text = runCatching { resolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) } }.getOrNull()
        if (text == null) { say("Couldn’t read that file"); return }
        tryRestore(text)
    }
    fun tryRestore(text: String) {
        val r = parseSaved(text.trim())
        if (r == null) { say("That isn’t a backup from this tracker. Nothing changed.", long = true); return }
        val n = r.data
        val games = n.teams.sumOf { it.games.size }; val ev = n.teams.sumOf { t -> t.games.sumOf { it.events.size } }
        sheet = Sheet.Confirm("Restore backup?",
            "Replace everything on this phone with the backup: ${plural(n.teams.size, "team")}, ${plural(games, "game")} and ${plural(ev, "logged stat")}." +
                (if (r.fixed > 0) " ${plural(r.fixed, "damaged item")} in it will be skipped or repaired." else ""),
            listOf(
                Action("Save current stats first", keepOpen = true) { exportBackup() },
                Action("Replace with backup", danger = true) {
                    engine.replace(n.copy(tab = data.tab)); viewGameId = null; keptOld = emptySet()
                    commit("Backup restored")
                }))
    }
    fun runAction(a: Action) { if (!a.keepOpen) sheet = null; a.run() }

    override fun onCleared() { io.shutdown() }
}
