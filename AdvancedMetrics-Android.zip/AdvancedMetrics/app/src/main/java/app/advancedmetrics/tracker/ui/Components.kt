package app.advancedmetrics.tracker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.advancedmetrics.tracker.core.Line

/** White board topped with a strip of rink paint, like the web tools' cards. */
@Composable
fun RinkCard(line: Line, modifier: Modifier = Modifier, dot: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    val r = LocalRink.current
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .background(r.surface)
            .border(1.dp, r.line, RoundedCornerShape(22.dp))
    ) {
        PaintStrip(line, dot)
        content()
    }
}

@Composable
fun PaintStrip(line: Line, dot: Boolean = false) {
    val r = LocalRink.current
    Box(Modifier.fillMaxWidth().height(if (line == Line.GOAL) 2.dp else 5.dp).background(if (line == Line.BLUE) r.blue else r.red)) {
        if (dot) Box(Modifier.align(Alignment.Center).size(12.dp).clip(CircleShape).background(r.blue))
    }
}

@Composable
fun ZoneHead(title: String, note: String = "", modifier: Modifier = Modifier) {
    val r = LocalRink.current
    Row(modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(title.uppercase(), style = Type.display(23.sp, r.ink), modifier = Modifier.weight(1f, fill = false))
        if (note.isNotEmpty()) {
            Spacer(Modifier.weight(1f))
            Text(note, style = Type.body(r.ink2, 13.5.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun Lbl(text: String, modifier: Modifier = Modifier, color: Color = LocalRink.current.ink2) {
    Text(text.uppercase(), style = Type.label(color), modifier = modifier)
}

enum class BtnKind { NORMAL, PRIMARY, DANGER, DANGER_FILL, QUIET }

@Composable
fun Btn(
    text: String, onClick: () -> Unit, modifier: Modifier = Modifier, kind: BtnKind = BtnKind.NORMAL,
    enabled: Boolean = true, small: Boolean = false, trailing: (@Composable () -> Unit)? = null
) {
    val r = LocalRink.current
    val (bg, fg, border) = when (kind) {
        BtnKind.PRIMARY -> Triple(r.ink, r.surface, r.ink)
        BtnKind.DANGER -> Triple(Color.Transparent, r.red, r.red)
        BtnKind.DANGER_FILL -> Triple(r.red, r.onRed, r.red)
        BtnKind.QUIET -> Triple(Color.Transparent, r.ink, r.line)
        BtnKind.NORMAL -> Triple(r.surface, r.ink, r.line)
    }
    val shape = RoundedCornerShape(if (small) 10.dp else 12.dp)
    Row(
        modifier
            .heightIn(min = if (small) 40.dp else 48.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(shape)
            .background(bg)
            .border(1.dp, border, shape)
            .clickable(enabled = enabled, role = Role.Button, onClick = onClick)
            .padding(horizontal = if (small) 12.dp else 14.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(7.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, style = Type.body(fg, if (small) 14.sp else 15.sp, FontWeight.Bold), maxLines = 1, overflow = TextOverflow.Ellipsis)
        trailing?.invoke()
    }
}

/** Small rounded count badge, as on the Setup tab and chips. */
@Composable
fun Count(n: Int, onDark: Boolean = false) {
    val r = LocalRink.current
    Text("$n", style = Type.body(if (onDark) r.surface else r.ink2, 12.sp, FontWeight.Bold),
        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (onDark) r.ink2 else r.surface2).padding(horizontal = 7.dp, vertical = 2.dp))
}

/** A row of options where one is chosen (periods, This game / Season). */
@Composable
fun <T> Segmented(
    options: List<T>, current: T, label: (T) -> String, onSelect: (T) -> Unit, modifier: Modifier = Modifier,
    display: Boolean = false, describe: (T) -> String = label, height: Dp = 40.dp
) {
    val r = LocalRink.current
    Row(
        modifier.clip(RoundedCornerShape(12.dp)).background(r.surface2).border(1.dp, r.line, RoundedCornerShape(12.dp)).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        options.forEach { o ->
            val on = o == current
            Box(
                Modifier.weight(1f).heightIn(min = height).clip(RoundedCornerShape(9.dp)).background(if (on) r.ink else Color.Transparent)
                    .clickable(role = Role.Tab) { onSelect(o) }.semantics { selected = on; contentDescription = describe(o) }
                    .padding(horizontal = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(label(o), maxLines = 1, style = if (display) Type.display(21.sp, if (on) r.surface else r.ink2)
                    else Type.body(if (on) r.surface else r.ink2, 14.sp, FontWeight.Bold))
            }
        }
    }
}

@Composable
fun Chip(text: String, on: Boolean, onClick: () -> Unit, count: Int? = null) {
    val r = LocalRink.current
    Row(
        Modifier.heightIn(min = 40.dp).clip(RoundedCornerShape(50)).background(if (on) r.ink else r.surface)
            .border(1.dp, if (on) r.ink else r.line, RoundedCornerShape(50)).clickable(role = Role.Button, onClick = onClick)
            .padding(start = 13.dp, end = if (count != null) 8.dp else 13.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        Text(text, style = Type.body(if (on) r.surface else r.ink2, 14.sp, FontWeight.Bold), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (count != null) Count(count, onDark = on)
    }
}

@Composable
fun Field(
    value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, placeholder: String = "",
    numeric: Boolean = false, big: Boolean = false, words: Boolean = false, singleLine: Boolean = true, minLines: Int = 1,
    imeDone: (() -> Unit)? = null, mono: Boolean = false
) {
    val r = LocalRink.current
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        if (label.isNotEmpty()) Lbl(label)
        OutlinedTextField(
            value = value, onValueChange = onChange, modifier = Modifier.fillMaxWidth(), singleLine = singleLine, minLines = minLines,
            placeholder = {
                if (placeholder.isNotEmpty()) Text(placeholder, style = if (big) Type.display(24.sp, r.ink2) else Type.body(r.ink2, 16.sp),
                    textAlign = if (big) TextAlign.Center else null, modifier = if (big) Modifier.fillMaxWidth() else Modifier)
            },
            textStyle = when {
                big -> Type.display(26.sp, r.red).copy(textAlign = TextAlign.Center)
                mono -> Type.body(r.ink, 14.sp).copy(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                else -> Type.body(r.ink, 16.sp)
            },
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = r.blue, unfocusedBorderColor = r.line, focusedContainerColor = r.surface, unfocusedContainerColor = r.surface2,
                cursorColor = r.blue, focusedTextColor = r.ink, unfocusedTextColor = r.ink
            ),
            keyboardOptions = KeyboardOptions(
                keyboardType = if (numeric) KeyboardType.Number else KeyboardType.Text,
                capitalization = if (words) KeyboardCapitalization.Words else KeyboardCapitalization.None,
                imeAction = if (singleLine) ImeAction.Done else ImeAction.Default
            ),
            // With no handler, pass null so Done does its default and closes the keyboard (any lambda here replaces that).
            keyboardActions = KeyboardActions(onDone = imeDone?.let { done -> { done() } })
        )
    }
}

/** Dashed box for gentle notices (sample team, logging to an older game). */
@Composable
fun Notice(text: String, modifier: Modifier = Modifier, actions: @Composable RowScope.() -> Unit) {
    val r = LocalRink.current
    Column(
        modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(r.surface).border(1.dp, r.ink2.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(text, style = Type.body(r.ink, 14.sp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), content = actions)
    }
}

@Composable
fun Pill(text: String, tone: String = "") {
    val r = LocalRink.current
    val c = when (tone) { "hi" -> r.ok; "lo" -> r.red; else -> r.ink2 }
    Text(text, style = Type.body(c, 12.sp, FontWeight.Bold), textAlign = TextAlign.Center, maxLines = 1,
        modifier = Modifier.widthIn(min = 44.dp).clip(RoundedCornerShape(50)).border(1.dp, if (tone.isEmpty()) r.line else c, RoundedCornerShape(50))
            .padding(horizontal = 6.dp, vertical = 2.dp))
}

@Composable
fun SampleTag() {
    val r = LocalRink.current
    Text("SAMPLE", style = Type.label(r.ink2, 10.sp), modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, r.ink2, RoundedCornerShape(50)).padding(horizontal = 6.dp, vertical = 1.dp))
}

@Composable
fun Rule() { Box(Modifier.fillMaxWidth().height(1.dp).background(LocalRink.current.line)) }
