package app.advancedmetrics.tracker.ui

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import app.advancedmetrics.tracker.core.*
import java.io.ByteArrayOutputStream
import java.text.DateFormat
import java.util.Date

/** Game and season reports in the rink style, drawn with Android's own PDF engine (works offline). */
object PdfReport {
    private const val INK = 0xFF0E1924.toInt(); private const val INK2 = 0xFF546372.toInt(); private const val RED = 0xFFC8102E.toInt()
    private const val BLUE = 0xFF1A4C9C.toInt(); private const val LINE = 0xFFD3DCE4.toInt(); private const val ICE = 0xFFEDF2F6.toInt(); private const val OK = 0xFF2B7A4B.toInt()

    private fun toneColor(a: Int, b: Int, hi: Int, lo: Int) = when (toneOf(a, b, hi, lo)) { "hi" -> OK; "lo" -> RED; else -> INK }

    private class Doc(landscape: Boolean) {
        val w = if (landscape) 792f else 612f
        val h = if (landscape) 612f else 792f
        val pages = mutableListOf(mutableListOf<(Canvas) -> Unit>())
        var cur = pages[0]
        fun addPage() { cur = mutableListOf(); pages.add(cur) }

        fun paint(size: Float, bold: Boolean, color: Int, spacing: Float = 0f, align: Paint.Align = Paint.Align.LEFT) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = size; typeface = Typeface.create(Typeface.SANS_SERIF, if (bold) Typeface.BOLD else Typeface.NORMAL)
            this.color = color; letterSpacing = spacing; textAlign = align
        }
        fun measure(s: String, size: Float, bold: Boolean, spacing: Float = 0f) = paint(size, bold, INK, spacing).measureText(s)
        fun fit(s: String, maxW: Float, size: Float, bold: Boolean, spacing: Float = 0f): String {
            if (measure(s, size, bold, spacing) <= maxW) return s
            var t = s
            while (t.isNotEmpty() && measure("$t…", size, bold, spacing) > maxW) t = t.dropLast(1)
            return t.trimEnd() + "…"
        }
        fun text(s: String, x: Float, y: Float, size: Float, bold: Boolean = false, color: Int = INK, align: Paint.Align = Paint.Align.LEFT, spacing: Float = 0f) {
            val p = paint(size, bold, color, spacing, align)
            cur.add { it.drawText(s, x, y, p) }
        }
        fun rect(x: Float, y: Float, rw: Float, rh: Float, color: Int) {
            val p = Paint().apply { this.color = color; style = Paint.Style.FILL }
            cur.add { it.drawRect(x, y, x + rw, y + rh, p) }
        }
        fun line(x1: Float, y1: Float, x2: Float, y2: Float, color: Int, width: Float = 0.6f) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; strokeWidth = width; style = Paint.Style.STROKE }
            cur.add { it.drawLine(x1, y1, x2, y2, p) }
        }
        fun circle(cx: Float, cy: Float, r: Float, color: Int) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.FILL }
            cur.add { it.drawCircle(cx, cy, r, p) }
        }

        fun output(note: String): ByteArray {
            val made = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date())
            val doc = PdfDocument()
            try {
                pages.forEachIndexed { i, ops ->
                    val page = doc.startPage(PdfDocument.PageInfo.Builder(w.toInt(), h.toInt(), i + 1).create())
                    val c = page.canvas
                    ops.forEach { it(c) }
                    val lp = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = LINE; strokeWidth = 0.6f }
                    c.drawLine(40f, h - 36f, w - 40f, h - 36f, lp)
                    c.drawText(fit("$note - generated $made", w - 170f, 8f, false), 40f, h - 22f, paint(8f, false, INK2))
                    c.drawText("Page ${i + 1} of ${pages.size}", w - 40f, h - 22f, paint(8f, false, INK2, align = Paint.Align.RIGHT))
                    doc.finishPage(page)
                }
                val out = ByteArrayOutputStream()
                doc.writeTo(out)
                return out.toByteArray()
            } finally { doc.close() }
        }
    }

    private fun head(d: Doc, eyebrow: String, title: String, sub: String): Float {
        val maxW = d.w - 80f
        d.rect(0f, 0f, d.w, 7f, RED); d.circle(d.w / 2, 3.5f, 6f, BLUE)
        d.text(eyebrow.uppercase(), 40f, 36f, 8f, true, INK2, spacing = 0.19f)
        val t = title.uppercase()
        var fs = 26f
        while (fs > 14f && d.measure(t, fs, true) > maxW) fs--
        d.text(d.fit(t, maxW, fs, true), 40f, 64f, fs, true)
        d.text(d.fit(sub, maxW, 11f, false), 40f, 82f, 11f, false, INK2)
        return 106f
    }
    private fun section(d: Doc, y0: Float, label: String, color: Int): Float {
        var y = y0
        if (y > d.h - 150f) { d.addPage(); y = 48f }
        d.rect(40f, y, d.w - 80f, 4f, color)
        d.text(label.uppercase(), 40f, y + 22f, 13f, true, spacing = 0.05f)
        return y + 34f
    }
    private class G(val k: String, val v: String, val s: String, val color: Int = INK)
    private fun glance(d: Doc, y: Float, items: List<G>): Float {
        val cw = (d.w - 80f) / items.size
        items.forEachIndexed { i, g ->
            val x = 40f + i * cw
            d.text(d.fit(g.k.uppercase(), cw - 8f, 7f, true, 0.05f), x, y + 8f, 7f, true, INK2, spacing = 0.05f)
            d.text(d.fit(g.v, cw - 8f, 20f, true), x, y + 32f, 20f, true, g.color)
            d.text(d.fit(g.s, cw - 8f, 8f, false), x, y + 45f, 8f, false, INK2)
        }
        d.line(40f, y + 56f, d.w - 40f, y + 56f, LINE)
        return y + 78f
    }

    private class Col(val w: Float, val left: Boolean)
    private class Cell(val t: String, val bold: Boolean = false, val color: Int = INK, val size: Float = 0f)
    private sealed interface Row
    private class Cells(val cells: List<Cell>, val fill: Int? = null, val bold: Boolean = false, val strong: Boolean = false) : Row
    private class SectionRow(val title: String) : Row
    private class NoteRow(val text: String) : Row

    /** Header labels up to two lines; one line per cell (long text gets an ellipsis); header repeats on each page. */
    private fun table(d: Doc, y0: Float, cols: List<Col>, head: List<String>, rows: List<Row>, fs: Float = 9.5f, pad: Float = 5f, rh: Float = 0f): Float {
        var y = y0
        val x0 = 40f; val tw = cols.sumOf { it.w.toDouble() }.toFloat(); val rowH = if (rh > 0) rh else Math.round(fs * 2 + 1).toFloat()
        val colX = ArrayList<Float>(); var acc = x0; cols.forEach { colX.add(acc); acc += it.w }
        fun ax(i: Int) = if (cols[i].left) colX[i] + pad else colX[i] + cols[i].w - pad
        fun al(i: Int) = if (cols[i].left) Paint.Align.LEFT else Paint.Align.RIGHT
        val heads = head.mapIndexed { i, h ->
            val up = h.uppercase(); val max = cols[i].w - 2 * pad
            if (d.measure(up, 7f, true, 0.04f) <= max || ' ' !in up) listOf(d.fit(up, max, 7f, true, 0.04f))
            else {
                val words = up.split(' ')
                val best = (1 until words.size).minByOrNull { k -> maxOf(d.measure(words.take(k).joinToString(" "), 7f, true, 0.04f), d.measure(words.drop(k).joinToString(" "), 7f, true, 0.04f)) }!!
                listOf(d.fit(words.take(best).joinToString(" "), max, 7f, true, 0.04f), d.fit(words.drop(best).joinToString(" "), max, 7f, true, 0.04f))
            }
        }
        val hh = heads.maxOf { it.size } * 8.5f + 9f
        fun drawHead() {
            heads.forEachIndexed { i, ls -> ls.forEachIndexed { j, ln -> d.text(ln, ax(i), y + 10f + j * 8.5f, 7f, true, INK2, al(i), 0.04f) } }
            y += hh; d.line(x0, y, x0 + tw, y, INK, 1.2f)
        }
        drawHead()
        for (row in rows) {
            val h = if (row is SectionRow) 15f else rowH
            if (y + h > d.h - 56f) { d.addPage(); y = 48f; drawHead() }
            when (row) {
                is SectionRow -> { d.rect(x0, y, tw, h, ICE); d.text(row.title.uppercase(), x0 + pad, y + h / 2 + 2.5f, 7f, true, INK2, spacing = 0.08f) }
                is NoteRow -> d.text(d.fit(row.text, tw - 2 * pad, fs, false), x0 + pad, y + h / 2 + fs * 0.35f, fs, false, INK2)
                is Cells -> {
                    row.fill?.let { d.rect(x0, y, tw, h, it) }
                    row.cells.forEachIndexed { i, c ->
                        val size = if (c.size > 0) c.size else fs; val bold = c.bold || row.bold
                        d.text(d.fit(c.t, cols[i].w - 2 * pad, size, bold), ax(i), y + h / 2 + size * 0.35f, size, bold, c.color, al(i))
                    }
                    if (row.strong) d.line(x0, y, x0 + tw, y, INK, 1f)
                }
            }
            y += h
            if (!(row is Cells && row.strong) && row !is SectionRow) d.line(x0, y, x0 + tw, y, LINE)
        }
        return y + 24f
    }

    private fun indRows(t: Team, p: Map<String, PStat>, season: Boolean): List<Row> {
        val rows = app.advancedmetrics.tracker.core.indRows(t, p).map { r ->
            val fo = r.s.FOW + r.s.FOL
            Cells(listOf(Cell(r.num, true, RED, 11f), Cell(r.name)) + (if (season) listOf(Cell("${r.games}")) else emptyList()) +
                listOf(Cell("${r.s.FOW}"), Cell("${r.s.FOL}"), if (fo > 0) Cell(pctS(r.s.FOW, fo), true, toneColor(r.s.FOW, fo, 52, 48)) else Cell("–"),
                    Cell("${r.s.BBW}"), Cell("${r.s.TO}")))
        }
        return rows.ifEmpty { listOf(NoteRow("No player stats logged.")) }
    }

    fun game(t: Team, g: Game, per: String): ByteArray {
        val c = tally(g.events, per)
        val perL = if (per == "all") "Full game" else perLong(per)
        val d = Doc(false); val tw = d.w - 80f
        val en = c["ENC"] + c["ENU"]; val ex = c["EXC"] + c["EXU"]
        var y = head(d, "Advanced metrics - game report", t.name, "vs ${g.opp} - ${fmtLong(g.date)} - $perL${if (g.sample) " - sample game" else ""}")
        y = section(d, y, "At a glance", RED)
        y = glance(d, y, listOf(
            G("Faceoff %", pctS(c["FOW"], c["FOW"] + c["FOL"]), "${c["FOW"]}–${c["FOL"]}", toneColor(c["FOW"], c["FOW"] + c["FOL"], 52, 48)),
            G("Ctrl entry %", pctS(c["ENC"], en), "${c["ENC"]} of $en", toneColor(c["ENC"], en, 55, 45)),
            G("Ctrl exit %", pctS(c["EXC"], ex), "${c["EXC"]} of $ex", toneColor(c["EXC"], ex, 65, 50)),
            G("Turnovers", "${c["TOO"] + c["TON"] + c["TOD"]}", "O ${c["TOO"]} / N ${c["TON"]} / D ${c["TOD"]}"),
            G("PP goals", "${c["PPF"]}–${c["PPA"]}", "for – against"),
            G("One-timers", "${c["OTS"]}", "${c["BBW"]} board battles won")))
        y = section(d, y, "Team metrics", BLUE)
        y = table(d, y, listOf(Col(tw - 200f, true), Col(110f, false), Col(90f, false)), listOf("Metric", "Count", "Rate"),
            teamRows(c).map { r ->
                when (r) {
                    is Sec -> SectionRow(r.title)
                    is Metric -> Cells(listOf(Cell(r.label), Cell(r.count), r.rate?.let { Cell(pctS(it.a, it.b), true, toneColor(it.a, it.b, it.hi, it.lo)) } ?: Cell("")))
                }
            }, rh = 17f)
        y = section(d, y, "Players", RED)
        table(d, y, listOf(Col(34f, true), Col(tw - 34f - 5 * 66f, true)) + List(5) { Col(66f, false) },
            listOf("#", "Player", "FO W", "FO L", "FO %", "Board battles won", "Turnovers"), indRows(t, c.players, false), rh = 18f)
        return d.output("${t.name} vs ${g.opp}")
    }

    fun season(t: Team): ByteArray {
        val gs = gamesOldest(t)
        val d = Doc(true); val tw = d.w - 80f
        var y = head(d, "Advanced metrics - season report", t.name, "${plural(gs.size, "game")} - ${seasonSpan(gs)}")
        y = section(d, y, "Game by game", RED)
        val headRow = listOf("Date", "Opponent", "FO W", "FO L", "FO %", "PPGF", "PPGA", "OZ TO", "NZ TO", "DZ TO", "Ctrl ent", "Tot ent", "Ent %",
            "Ctrl exit", "Tot exit", "Exit %", "One timers", "BB won")
        val nw = (tw - 48f - 112f) / 16f
        val cols = listOf(Col(48f, true), Col(112f, true)) + List(16) { Col(nw, false) }
        val rows: MutableList<Row> = gs.map { g -> Cells(listOf(Cell(fmtShort(g.date)), Cell(g.opp + if (g.sample) " (sample)" else "")) + seasonRow(tally(g.events)).map { Cell(it) }) }.toMutableList()
        rows.add(Cells(listOf(Cell("Totals"), Cell(plural(gs.size, "game"))) + seasonRow(seasonTally(t)).map { Cell(it) }, fill = ICE, bold = true, strong = true))
        y = table(d, y, cols, headRow, rows, fs = 8.5f, pad = 4f)
        y = section(d, y, "Players - season totals", BLUE)
        table(d, y, listOf(Col(34f, true), Col(tw - 34f - 6 * 70f, true)) + List(6) { Col(70f, false) },
            listOf("#", "Player", "GP", "FO W", "FO L", "FO %", "Board battles won", "Turnovers"), indRows(t, seasonPlayers(t), true))
        return d.output("${t.name} season")
    }
}
