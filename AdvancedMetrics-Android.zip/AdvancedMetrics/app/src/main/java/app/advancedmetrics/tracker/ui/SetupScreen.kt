package app.advancedmetrics.tracker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.advancedmetrics.tracker.core.*

fun LazyListScope.setupScreen(vm: AppViewModel, d: AppData) {
    item(key = "team") { TeamCard(vm, d) }
    item(key = "roster") { RosterCard(vm) }
    item(key = "games") { GamesCard(vm) }
    item(key = "tracking") { TrackingCard(vm, d) }
    item(key = "backup") { BackupCard(vm) }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun TeamCard(vm: AppViewModel, d: AppData) {
    val t = vm.team()
    val focus = LocalFocusManager.current
    RinkCard(Line.RED, Modifier.gut(), dot = true) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            ZoneHead("Team", if (t.sample) "Sample team" else "")
            var name by remember(t.id, t.name) { mutableStateOf(t.name) }
            val commitName: () -> Unit = { if (name != t.name) { if (!vm.renameTeam(t.id, name)) name = t.name } }
            // Leaving the tab saves an edited name too. Keyed like `name` so the callback always sees the live field; keyed
            // on the id alone it kept the first field, and after one rename it saved that stale text over later edits.
            DisposableEffect(t.id, t.name) { onDispose { commitName() } }
            Field(name, { name = it }, "Team name", Modifier.onFocusChanged { if (!it.hasFocus) commitName() },
                words = true, imeDone = { focus.clearFocus() })
            if (d.teams.size > 1) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Lbl("Switch team")
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        d.teams.forEach { x -> Chip(x.name, x.id == t.id, { vm.switchTeam(x.id) }, x.games.size) }
                    }
                }
            }
            var newTeam by rememberSaveable { mutableStateOf("") }
            val addTeam: () -> Unit = { if (vm.addTeam(newTeam)) newTeam = "" else vm.say("Enter a team name") }
            Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Field(newTeam, { newTeam = it }, "Add another team", Modifier.weight(1f), placeholder = "e.g. 14U Travel", words = true,
                    imeDone = addTeam)
                Btn("Add team", addTeam, Modifier.padding(bottom = 4.dp))
            }
            Btn("Delete this team", { vm.askDeleteTeam() }, kind = BtnKind.DANGER, enabled = d.teams.size > 1)
        }
    }
}

@Composable
private fun RosterCard(vm: AppViewModel) {
    val r = LocalRink.current
    val t = vm.team()
    val act = vm.engine.activeRoster()
    val gone = t.roster.filter { it.gone && it.name != "Removed player" }.sortedWith(byNum)
    val counts = playerCounts(t); val dups = dupNums(t)
    RinkCard(Line.BLUE, Modifier.gut()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ZoneHead("Roster", if (act.isNotEmpty()) plural(act.size, "player") else "")
            if (dups.isNotEmpty()) {
                val dl = dups.sortedBy { it.toInt() }
                Text("Jersey ${if (dl.size > 1) "numbers" else "number"} used twice: ${dl.joinToString(", ") { "#$it" }}. Fix ${if (dl.size > 1) "these" else "this"} so stats go to the right player.",
                    style = Type.body(r.warn, 13.5.sp, FontWeight.SemiBold),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border(1.dp, r.warn, RoundedCornerShape(12.dp)).padding(10.dp))
            }
            var num by rememberSaveable { mutableStateOf("") }
            var name by rememberSaveable { mutableStateOf("") }
            val add: () -> Unit = {
                if (vm.addPlayer(num, name)) { num = ""; name = "" } else vm.say("Enter the player’s name")
            }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Field(num, { num = it.filter(Char::isDigit).take(3) }, "#", Modifier.width(84.dp), placeholder = "00", numeric = true, big = true)
                Field(name, { name = it }, "Player name", Modifier.weight(1f), placeholder = "First and last name", words = true, imeDone = add)
            }
            Btn("Add player", add, Modifier.fillMaxWidth(), kind = BtnKind.PRIMARY)
            var pasteOpen by rememberSaveable { mutableStateOf(false) }
            var paste by rememberSaveable { mutableStateOf("") }
            Row(Modifier.fillMaxWidth().heightIn(min = 44.dp).clickable(role = Role.Button) { pasteOpen = !pasteOpen }, verticalAlignment = Alignment.CenterVertically) {
                Text("Paste a whole roster", style = Type.body(r.ink, 15.sp, FontWeight.Bold), modifier = Modifier.weight(1f))
                Text(if (pasteOpen) "–" else "+", style = Type.body(r.ink2, 22.sp))
            }
            if (pasteOpen) {
                Text("One player per line, number first: 9 Mike Costa or 9, Costa, Mike. Rows copied from a spreadsheet work too, with or without a header row. Players already on the roster are skipped.",
                    style = Type.body(r.ink2, 13.5.sp))
                Field(paste, { paste = it }, "", placeholder = "4 Alvarez\n7 Brennan\n9 Mike Costa", singleLine = false, minLines = 5, mono = true)
                Btn("Add list", { if (paste.isBlank()) vm.say("Paste a list first") else { vm.pasteRoster(paste); paste = "" } }, Modifier.fillMaxWidth())
            }
        }
        if (act.isEmpty()) {
            Rule(); Text("No players yet. Add them above or paste a list.", style = Type.body(r.ink2, 14.sp), modifier = Modifier.padding(14.dp))
        }
        act.forEach { p ->
            Rule()
            Row(Modifier.fillMaxWidth().heightIn(min = 54.dp).clickable(role = Role.Button) { vm.openSheet(Sheet.PlayerEdit(p.id)) }.padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(p.num.ifEmpty { "–" }, style = Type.display(26.sp, r.red), textAlign = TextAlign.Center, modifier = Modifier.width(44.dp))
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(p.name, style = Type.body(r.ink, 15.sp, FontWeight.SemiBold), maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (isDup(dups, p)) Text("DUPLICATE #", style = Type.label(r.warn, 10.sp))
                }
                Text(plural(counts[p.id] ?: 0, "stat"), style = Type.body(r.ink2, 12.sp, FontWeight.Bold),
                    modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, r.line, RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 4.dp))
            }
        }
        if (gone.isNotEmpty()) {
            Row(Modifier.fillMaxWidth().background(r.surface2).padding(horizontal = 14.dp, vertical = 9.dp)) {
                Lbl("Removed · still in reports", Modifier.weight(1f)); Lbl("${gone.size}")
            }
            gone.forEach { p ->
                Rule()
                Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(p.num.ifEmpty { "–" }, style = Type.display(22.sp, r.ink2), textAlign = TextAlign.Center, modifier = Modifier.width(44.dp))
                    Text(p.name, style = Type.body(r.ink2, 15.sp), modifier = Modifier.weight(1f))
                    Btn("Put back", { vm.restorePlayer(p.id) }, small = true)
                }
            }
        }
    }
}

@Composable
private fun GamesCard(vm: AppViewModel) {
    val t = vm.team(); val gs = gamesNewest(t)
    RinkCard(Line.GOAL, Modifier.gut()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ZoneHead("Games", if (gs.isNotEmpty()) plural(gs.size, "game") else "")
            Btn("New game", { vm.openSheet(Sheet.Games(true)) }, kind = BtnKind.PRIMARY)
        }
        if (gs.isEmpty()) { Rule(); Text("No games yet.", style = Type.body(LocalRink.current.ink2, 14.sp), modifier = Modifier.padding(14.dp)) }
        gs.forEach { g -> Rule(); GameRow(g, g.id == t.gameId, Modifier.padding(horizontal = 14.dp)) { vm.openSheet(Sheet.GameEdit(g.id)) } }
    }
}

@Composable
fun GameRow(g: Game, tracking: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val r = LocalRink.current
    Row(Modifier.fillMaxWidth().clickable(role = Role.Button, onClick = onClick).then(modifier).padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Column(Modifier.width(48.dp).clip(RoundedCornerShape(10.dp)).background(r.surface2).border(1.dp, r.line, RoundedCornerShape(10.dp)).padding(vertical = 5.dp),
            horizontalAlignment = Alignment.CenterHorizontally) {
            Text(fmtMonth(g.date).uppercase(), style = Type.label(r.red, 10.sp))
            Text(fmtDayNum(g.date), style = Type.display(22.sp, r.ink), lineHeight = 22.sp)
        }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("vs ${g.opp}", style = Type.body(r.ink, 15.sp, FontWeight.Bold), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                if (g.sample) SampleTag()
            }
            Text("${fmtWeekday(g.date)} · ${plural(g.events.size, "entry", "entries")}", style = Type.body(r.ink2, 12.5.sp))
        }
        if (tracking) Text("TRACKING", style = Type.label(r.ok, 10.5.sp),
            modifier = Modifier.clip(RoundedCornerShape(50)).border(1.dp, r.ok, RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 3.dp))
    }
}

@Composable
private fun TrackingCard(vm: AppViewModel, d: AppData) {
    val r = LocalRink.current
    RinkCard(Line.BLUE, Modifier.gut()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ZoneHead("Tracking")
            Row(Modifier.fillMaxWidth().clickable(role = Role.Switch) { vm.setAskWho(!d.askWho) }, verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Ask which player", style = Type.body(r.ink, 15.sp, FontWeight.Bold))
                    Text("After a faceoff, turnover or board battle tap, pick the player. Turn off to log team totals only.", style = Type.body(r.ink2, 13.5.sp))
                }
                Switch(d.askWho, { vm.setAskWho(it) }, colors = SwitchDefaults.colors(checkedTrackColor = r.ok, checkedThumbColor = r.surface,
                    uncheckedTrackColor = r.line, uncheckedThumbColor = r.surface, uncheckedBorderColor = r.line))
            }
        }
    }
}

@Composable
private fun BackupCard(vm: AppViewModel) {
    val r = LocalRink.current
    val clip = LocalClipboardManager.current
    RinkCard(Line.GOAL, Modifier.gut()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ZoneHead("Backup")
            Text("Stats are kept on this phone. A backup moves them to another phone, keeps a copy safe, or brings them over from the web version of the tracker.",
                style = Type.body(r.ink2, 13.5.sp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Save backup file", { vm.exportBackup() }, Modifier.weight(1f))
                Btn("Copy backup", {
                    // A full season can be bigger than Android lets the clipboard carry (about 1 MB), and that throws.
                    if (runCatching { clip.setText(AnnotatedString(vm.backupText())) }.isSuccess) vm.say("Backup copied. Paste it somewhere safe.")
                    else vm.say("This backup is too big to copy. Use Save backup file instead.", long = true)
                }, Modifier.weight(1f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Restore a backup", { vm.openSheet(Sheet.Restore) }, Modifier.weight(1f))
                Btn("Load sample team", { vm.loadSample() }, Modifier.weight(1f))
            }
        }
    }
}
