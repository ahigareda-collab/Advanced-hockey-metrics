package app.advancedmetrics.tracker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.advancedmetrics.tracker.core.*
import java.time.LocalDate

private const val DAY_MS = 86_400_000L

/** Short names for the picker: last names, with a first initial where two players share one. */
fun pickLabels(list: List<Player>): List<String> {
    val parts = list.map { p ->
        val t = p.name.trim().split(Regex("\\s+"))
        if (t.size < 2) "" to (t.firstOrNull() ?: "") else {
            var k = t.size - 1
            if (k >= 2 && Regex("^(jr|sr|ii|iii|iv)\\.?$", RegexOption.IGNORE_CASE).matches(t[k])) k--
            t.subList(0, k).joinToString(" ") to t.subList(k, t.size).joinToString(" ")
        }
    }
    val count = parts.groupingBy { it.second.lowercase() }.eachCount()
    return parts.map { (first, last) -> if ((count[last.lowercase()] ?: 0) > 1 && first.isNotEmpty()) "${first[0]}. $last" else last }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SheetHost(vm: AppViewModel, pickBackup: () -> Unit, messages: @Composable () -> Unit) {
    val s = vm.sheet ?: return
    val r = LocalRink.current
    val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    ModalBottomSheet(
        onDismissRequest = { vm.closeSheet(cancelled = true) }, sheetState = state, containerColor = r.surface, contentColor = r.ink,
        scrimColor = r.ink.copy(alpha = 0.42f), dragHandle = { BottomSheetDefaults.DragHandle(color = r.line) }
    ) {
        Column(Modifier.fillMaxWidth().imePadding()) {
            when (s) {
                is Sheet.Who -> WhoSheet(vm, s.k)
                Sheet.Log -> LogSheet(vm)
                is Sheet.Entry -> EntrySheet(vm, s.id)
                is Sheet.Games -> GamesSheet(vm)
                is Sheet.PlayerEdit -> PlayerSheet(vm, s.id)
                is Sheet.GameEdit -> GameSheet(vm, s.id)
                is Sheet.Confirm -> ConfirmSheet(vm, s)
                Sheet.Restore -> RestoreSheet(vm, pickBackup)
            }
            // Snackbars on the screen behind are covered by the sheet, so errors like a bad backup would go unseen.
            messages()
        }
    }
}

@Composable
private fun Head(vm: AppViewModel, title: String, sub: String = "") {
    val r = LocalRink.current
    Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 12.dp, bottom = 10.dp), verticalAlignment = Alignment.Top) {
        Column(Modifier.weight(1f)) {
            Text(title.uppercase(), style = Type.display(23.sp, r.ink))
            if (sub.isNotEmpty()) Text(sub, style = Type.body(r.ink2, 13.5.sp, FontWeight.SemiBold), maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).border(1.dp, r.line, RoundedCornerShape(10.dp))
            .clickable(role = Role.Button) { vm.closeSheet(cancelled = true) }, contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Close, "Close", tint = r.ink, modifier = Modifier.size(18.dp))
        }
    }
    Rule()
}

@Composable
private fun ColumnScope.Body(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
}

@Composable
private fun Foot(content: @Composable RowScope.() -> Unit) {
    Rule()
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), content = content)
}

/** Grid of jersey numbers: one tap credits the player. */
@Composable
private fun PlayerGrid(players: List<Player>, chosen: String?, highlight: String?, withTeam: Boolean, onPick: (String?) -> Unit) {
    val r = LocalRink.current
    val labels = pickLabels(players)
    val cells: List<Pair<Player?, String>> = (if (withTeam) listOf(null to "Team only") else emptyList()) + players.mapIndexed { i, p -> p to labels[i] }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        cells.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (p, label) ->
                    val on = if (p == null) chosen == null else chosen == p.id
                    val last = p != null && p.id == highlight
                    Column(
                        Modifier.weight(1f).heightIn(min = 70.dp).clip(RoundedCornerShape(12.dp)).background(if (on) r.ink else r.surface2)
                            .border(if (last) 2.dp else 1.dp, if (on) r.ink else if (last) r.blue else r.line, RoundedCornerShape(12.dp))
                            .clickable(role = Role.Button) { onPick(p?.id) }
                            .semantics { selected = on; contentDescription = (if (p == null) "Team only" else (if (p.num.isNotEmpty()) "#${p.num} " else "") + p.name) + if (last) ", picked last time" else "" }
                            .padding(horizontal = 4.dp, vertical = 9.dp),
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp, Alignment.CenterVertically)
                    ) {
                        Text(if (p == null) "–" else p.num.ifEmpty { "–" }, style = Type.display(30.sp, if (on) r.surface else if (p == null) r.ink2 else r.red), lineHeight = 30.sp)
                        Text(label.uppercase(), style = Type.label(if (on) r.surface else r.ink, 10.5.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun ColumnScope.WhoSheet(vm: AppViewModel, k: String) {
    Head(vm, EV.getValue(k).name, "Who? · ${perLong(vm.data.per)}")
    Body { PlayerGrid(vm.engine.activeRoster(), chosen = "", highlight = vm.engine.lastPick[k], withTeam = false) { vm.pickWho(it) } }
    Foot { Btn("Team only", { vm.pickWho(null) }, Modifier.weight(1f)) }
}

@Composable
private fun ColumnScope.LogSheet(vm: AppViewModel) {
    val r = LocalRink.current
    val g = vm.game() ?: run { LaunchedEffect(Unit) { vm.closeSheet() }; return }
    Head(vm, "Game log", "${plural(g.events.size, "entry", "entries")} · ${gLabel(g)}")
    val ev = g.events.asReversed()
    if (ev.isEmpty()) {
        Body { Text("Nothing logged in this game yet.", style = Type.body(r.ink2, 14.sp)) }
    } else {
        Text("Tap an entry to change its player or period.", style = Type.body(r.ink2, 13.5.sp), modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp))
        LazyColumn(Modifier.weight(1f, fill = false), contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)) {
            items(ev, key = { it.id }) { e ->
                val t = EV.getValue(e.k)
                Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(perShort(e.per), style = Type.display(17.sp, r.ink2), textAlign = TextAlign.Center, modifier = Modifier.width(36.dp))
                    Column(Modifier.weight(1f).heightIn(min = 46.dp).clip(RoundedCornerShape(10.dp)).clickable(role = Role.Button) { vm.openSheet(Sheet.Entry(e.id)) }
                        .padding(horizontal = 6.dp, vertical = 4.dp), verticalArrangement = Arrangement.Center) {
                        Text(t.name, style = Type.body(when (t.tone) { Tone.GOOD -> r.ok; Tone.BAD -> r.red; else -> r.ink }, 15.sp, FontWeight.Bold))
                        if (t.ind) Text(if (e.p != null) vm.engine.pName(e.p) else "Team only", style = Type.body(r.ink2, 13.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).border(1.dp, r.line, RoundedCornerShape(10.dp))
                        .clickable(role = Role.Button) { vm.deleteEntry(e.id) }.semantics { contentDescription = "Delete ${vm.engine.descEv(e)}, ${perShort(e.per)}" },
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Close, null, tint = r.ink2, modifier = Modifier.size(16.dp))
                    }
                }
                Rule()
            }
        }
    }
    Foot {
        Btn("Undo", { vm.undo() }, Modifier.weight(1f), enabled = vm.engine.canUndo())
        Btn("Done", { vm.closeSheet() }, Modifier.weight(1f), kind = BtnKind.PRIMARY)
    }
}

@Composable
private fun ColumnScope.EntrySheet(vm: AppViewModel, id: String) {
    val g = vm.game()
    val e = g?.events?.find { it.id == id } ?: run { LaunchedEffect(id) { vm.openSheet(Sheet.Log) }; return }
    val t = EV.getValue(e.k)
    val time = if (e.ts > 1_000_000_000_000L) java.text.DateFormat.getTimeInstance(java.text.DateFormat.SHORT).format(java.util.Date(e.ts)) else ""
    Head(vm, "Edit entry", t.name + if (time.isNotEmpty()) " · logged $time" else "")
    Body {
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Lbl("Period")
            Segmented(PERS, e.per, { it }, { vm.editEntryPer(id, it) }, Modifier.widthIn(max = 320.dp), display = true, describe = { perLong(it) }, height = 42.dp)
        }
        if (t.ind) {
            val roster = vm.engine.activeRoster().toMutableList()
            if (e.p != null && roster.none { it.id == e.p }) vm.engine.player(e.p)?.let { roster.add(it) }
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Lbl("Player")
                PlayerGrid(roster, chosen = e.p, highlight = null, withTeam = true) { vm.editEntryWho(id, it) }
            }
        }
        Btn("Delete entry", { vm.deleteEntry(id) }, kind = BtnKind.DANGER)
    }
    Foot {
        Btn("Back to log", { vm.openSheet(Sheet.Log) }, Modifier.weight(1f))
        Btn("Done", { vm.closeSheet() }, Modifier.weight(1f), kind = BtnKind.PRIMARY)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(date: String, onDate: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    val r = LocalRink.current
    var open by remember { mutableStateOf(false) }
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Lbl(label)
        Row(Modifier.fillMaxWidth().heightIn(min = 56.dp).clip(RoundedCornerShape(12.dp)).background(r.surface2).border(1.dp, r.line, RoundedCornerShape(12.dp))
            .clickable(role = Role.Button) { open = true }.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (parseDay(date) != null) fmtLong(date) else "Pick a date", style = Type.body(r.ink, 16.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
    if (open) {
        val st = rememberDatePickerState(initialSelectedDateMillis = (parseDay(date) ?: LocalDate.now()).toEpochDay() * DAY_MS)
        DatePickerDialog(
            onDismissRequest = { open = false },
            confirmButton = { TextButton({ st.selectedDateMillis?.let { onDate(LocalDate.ofEpochDay(Math.floorDiv(it, DAY_MS)).toString()) }; open = false }) { Text("OK") } },
            dismissButton = { TextButton({ open = false }) { Text("Cancel") } }
        ) { DatePicker(st) }
    }
}

@Composable
private fun ColumnScope.GamesSheet(vm: AppViewModel) {
    val r = LocalRink.current
    val t = vm.team(); val gs = gamesNewest(t)
    Head(vm, "Games", t.name)
    Body {
        if (vm.data.teams.size > 1) {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Lbl("Team")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    vm.data.teams.forEach { x -> Chip(x.name, x.id == t.id, { vm.switchTeam(x.id) }, x.games.size) }
                }
            }
        }
        var date by rememberSaveable { mutableStateOf(today()) }
        var opp by rememberSaveable { mutableStateOf("") }
        var err by remember { mutableStateOf("") }
        val start: () -> Unit = { err = vm.startGame(date, opp) ?: "" }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(r.surface2).border(1.dp, r.line, RoundedCornerShape(16.dp)).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Lbl("New game")
            DateField(date, { date = it }, "Date")
            Field(opp, { opp = it; err = "" }, "Opponent", placeholder = "e.g. Cherry Hill", words = true, imeDone = start)
            if (err.isNotEmpty()) Text(err, style = Type.body(r.red, 13.5.sp, FontWeight.SemiBold))
            Btn("Start game", start, Modifier.fillMaxWidth(), kind = BtnKind.PRIMARY)
        }
        if (gs.isNotEmpty()) {
            Row(Modifier.fillMaxWidth()) { Lbl("${t.name} games", Modifier.weight(1f)); Lbl("${gs.size}") }
            Column {
                gs.forEachIndexed { i, g -> if (i > 0) Rule(); GameRow(g, g.id == t.gameId) { vm.switchGame(g.id) } }
            }
        }
    }
}

@Composable
private fun ColumnScope.PlayerSheet(vm: AppViewModel, id: String) {
    val r = LocalRink.current
    val p = vm.engine.player(id) ?: run { LaunchedEffect(id) { vm.closeSheet() }; return }
    val n = playerCounts(vm.team())[id] ?: 0
    Head(vm, "Edit player", vm.engine.pName(id))
    var num by rememberSaveable(id) { mutableStateOf(p.num) }
    var name by rememberSaveable(id) { mutableStateOf(p.name) }
    var confirm by remember(id) { mutableStateOf(false) }
    Body {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Field(num, { num = it.filter(Char::isDigit).take(3) }, "#", Modifier.width(84.dp), numeric = true, big = true)
            Field(name, { name = it }, "Name", Modifier.weight(1f), words = true, imeDone = { if (!vm.savePlayer(id, num, name)) vm.say("Enter the player’s name") })
        }
        Btn("Save", { if (!vm.savePlayer(id, num, name)) vm.say("Enter the player’s name") }, Modifier.fillMaxWidth(), kind = BtnKind.PRIMARY)
        if (!confirm) Btn("Remove from roster", { confirm = true }, Modifier.fillMaxWidth(), kind = BtnKind.DANGER)
        else Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border(1.dp, r.red, RoundedCornerShape(12.dp)).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text(if (n > 0) "${p.name} has ${plural(n, "logged stat")}. They stay in your reports after removal, and you can put them back later." else "Remove ${p.name} from the roster?",
                style = Type.body(r.ink, 14.5.sp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Remove", { vm.removePlayer(id) }, Modifier.weight(1f), kind = BtnKind.DANGER_FILL)
                Btn("Keep", { confirm = false }, Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun ColumnScope.GameSheet(vm: AppViewModel, id: String) {
    val r = LocalRink.current
    val t = vm.team()
    val g = t.games.find { it.id == id } ?: run { LaunchedEffect(id) { vm.closeSheet() }; return }
    Head(vm, "Edit game", "${gLabel(g)} · ${plural(g.events.size, "entry", "entries")}")
    var date by rememberSaveable(id) { mutableStateOf(g.date) }
    var opp by rememberSaveable(id) { mutableStateOf(g.opp) }
    var err by remember(id) { mutableStateOf("") }
    Body {
        DateField(date, { date = it; err = "" }, "Date")
        Field(opp, { opp = it; err = "" }, "Opponent", words = true)
        if (err.isNotEmpty()) Text(err, style = Type.body(r.red, 13.5.sp, FontWeight.SemiBold))
        Btn("Save", { err = vm.saveGame(id, date, opp) ?: "" }, Modifier.fillMaxWidth(), kind = BtnKind.PRIMARY)
        if (g.id != t.gameId) Btn("Track this game", { vm.trackGame(id) }, Modifier.fillMaxWidth())
        Btn("Delete game", { vm.askDeleteGame(id) }, Modifier.fillMaxWidth(), kind = BtnKind.DANGER)
    }
}

@Composable
private fun ColumnScope.ConfirmSheet(vm: AppViewModel, s: Sheet.Confirm) {
    val r = LocalRink.current
    Head(vm, s.title)
    Body {
        Text(s.message, style = Type.body(r.ink, 15.sp))
        s.actions.forEach { a -> Btn(a.label, { vm.runAction(a) }, Modifier.fillMaxWidth(), kind = if (a.danger) BtnKind.DANGER_FILL else BtnKind.NORMAL) }
        Btn("Cancel", { vm.closeSheet() }, Modifier.fillMaxWidth(), kind = BtnKind.QUIET)
    }
}

@Composable
private fun ColumnScope.RestoreSheet(vm: AppViewModel, pickBackup: () -> Unit) {
    val r = LocalRink.current
    Head(vm, "Restore a backup", "This replaces the teams and stats on this phone.")
    // Not rememberSaveable: a pasted season backup can pass Android's ~1 MB saved-state limit, which crashes the app when it
    // goes into the background.
    var text by remember { mutableStateOf("") }
    Body {
        Btn("Choose a backup file", pickBackup, Modifier.fillMaxWidth())
        Text("Or paste a backup copied from this app or from the web tracker (Setup › Copy backup).", style = Type.body(r.ink2, 13.5.sp))
        Field(text, { text = it }, "", placeholder = "Paste the backup here", singleLine = false, minLines = 5, mono = true)
        Btn("Restore pasted backup", { if (text.isBlank()) vm.say("Paste a backup or choose a file first") else vm.tryRestore(text) }, Modifier.fillMaxWidth(), kind = BtnKind.PRIMARY)
    }
}
