package app.advancedmetrics.tracker.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.advancedmetrics.tracker.core.*

fun LazyListScope.statsScreen(vm: AppViewModel, d: AppData) {
    val t = vm.team()
    item(key = "tools") { StatsTools(vm, d) }
    if (d.statsView == "season") {
        val gs = gamesOldest(t)
        if (gs.isEmpty()) {
            item(key = "s-empty") { NoGames(vm, "No games yet", "Season totals build up here as you track games.") }
            return
        }
        item(key = "s-head") { SeasonHead(vm, t, gs) }
        item(key = "s-games") { SeasonGames(vm, t, gs) }
        item(key = "s-players") { PlayersCard(t, seasonPlayers(t), season = true) }
    } else {
        val g = vm.viewGame()
        if (g == null) {
            item(key = "g-empty") { NoGames(vm, "No game yet", "Start a game on the Track tab and its numbers show up here.") }
            return
        }
        val c = tally(g.events, d.sumPer)
        item(key = "g-head") { GameHead(g, c, d.sumPer) }
        item(key = "g-team") { TeamMetrics(c) }
        item(key = "g-players") { PlayersCard(t, c.players, season = false) }
    }
}

@Composable
private fun NoGames(vm: AppViewModel, title: String, text: String) {
    RinkCard(Line.RED, Modifier.gut(), dot = true) {
        EmptyState(title, text) { Btn("Start a game", { vm.openSheet(Sheet.Games(true)) }, kind = BtnKind.PRIMARY) }
    }
}

@Composable
private fun StatsTools(vm: AppViewModel, d: AppData) {
    val r = LocalRink.current
    val clip = LocalClipboardManager.current
    val t = vm.team(); val vg = vm.viewGame(); val season = d.statsView == "season"
    RinkCard(Line.BLUE, Modifier.gut()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Segmented(listOf("game", "season"), d.statsView, { if (it == "season") "Season" else "This game" }, { vm.setStatsView(it) }, Modifier.fillMaxWidth())
            if (!season && vg != null) {
                var open by remember { mutableStateOf(false) }
                val cur = vm.game()
                Box {
                    Row(
                        Modifier.fillMaxWidth().heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp)).background(r.surface2)
                            .border(1.dp, r.line, RoundedCornerShape(12.dp)).clickable(role = Role.Button) { open = true }.padding(horizontal = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(gLabel(vg) + if (cur?.id == vg.id) " · tracking" else "", style = Type.body(r.ink, 16.sp), maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                        Icon(Icons.Default.KeyboardArrowDown, "Choose a game", tint = r.ink2)
                    }
                    DropdownMenu(open, { open = false }) {
                        gamesNewest(t).forEach { g ->
                            DropdownMenuItem(
                                text = { Text(gLabel(g) + (if (cur?.id == g.id) " · tracking" else "") + if (g.sample) " · sample" else "", style = Type.body(r.ink, 15.sp, if (g.id == vg.id) FontWeight.Bold else FontWeight.Normal)) },
                                onClick = { open = false; vm.openGameStats(g.id) }
                            )
                        }
                    }
                }
                Segmented(listOf("all") + PERS, d.sumPer, { if (it == "all") "Game" else perShort(it) }, { vm.setSumPer(it) }, Modifier.fillMaxWidth(),
                    describe = { if (it == "all") "Full game" else perLong(it) })
            }
            val ok = if (season) t.games.isNotEmpty() else vg != null
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Btn("Excel", { vm.exportExcel() }, Modifier.weight(1f), kind = BtnKind.PRIMARY, enabled = t.games.isNotEmpty())
                Btn("PDF", { vm.exportPdf() }, Modifier.weight(1f), enabled = ok)
                Btn("Copy table", { clip.setText(AnnotatedString(vm.copyText())); vm.say("Copied. Paste into Excel or Sheets.") }, Modifier.weight(1.2f), enabled = ok)
            }
            Text("Excel holds the game shown, by period, plus the season game by game and player totals, with working formulas. PDF and Copy match what’s on screen.",
                style = Type.body(r.ink2, 13.5.sp))
        }
    }
}

@Composable
private fun Tiles(items: List<Tile>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items.chunked(2).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { TileBox(it, Modifier.weight(1f)) }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
    }
}
class Tile(val k: String, val v: String, val s: String, val tone: String = "")

@Composable
private fun TileBox(t: Tile, modifier: Modifier) {
    val r = LocalRink.current
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(r.surface2).border(1.dp, r.line, RoundedCornerShape(12.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(t.k.uppercase(), style = Type.label(r.ink2, 10.5.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(t.v, style = Type.display(34.sp, when (t.tone) { "hi" -> r.ok; "lo" -> r.red; else -> r.ink }), maxLines = 1, lineHeight = 36.sp)
        Text(t.s, style = Type.body(r.ink2, 12.5.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun GameHead(g: Game, c: Tally, per: String) {
    val r = LocalRink.current
    val en = c["ENC"] + c["ENU"]; val ex = c["EXC"] + c["EXU"]
    RinkCard(Line.RED, Modifier.gut(), dot = true) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("VS ${g.opp.uppercase()}", style = Type.display(23.sp, r.ink), modifier = Modifier.weight(1f, fill = false))
                    if (g.sample) SampleTag()
                }
                Text("${fmtDay(g.date)} · ${if (per == "all") "Full game" else perLong(per)}", style = Type.body(r.ink2, 13.5.sp))
            }
            Tiles(listOf(
                Tile("Faceoff %", pctS(c["FOW"], c["FOW"] + c["FOL"]), "${c["FOW"]}–${c["FOL"]}", toneOf(c["FOW"], c["FOW"] + c["FOL"], 52, 48)),
                Tile("Ctrl entry %", pctS(c["ENC"], en), "${c["ENC"]} of $en", toneOf(c["ENC"], en, 55, 45)),
                Tile("Ctrl exit %", pctS(c["EXC"], ex), "${c["EXC"]} of $ex", toneOf(c["EXC"], ex, 65, 50)),
                Tile("Turnovers", "${c["TOO"] + c["TON"] + c["TOD"]}", "O ${c["TOO"]} · N ${c["TON"]} · D ${c["TOD"]}"),
                Tile("PP goals", "${c["PPF"]}–${c["PPA"]}", "for – against"),
                Tile("One-timers", "${c["OTS"]}", "${c["BBW"]} board battles won")
            ))
        }
    }
}

@Composable
private fun TeamMetrics(c: Tally) {
    val r = LocalRink.current
    RinkCard(Line.BLUE, Modifier.gut()) {
        ZoneHead("Team metrics", modifier = Modifier.padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 8.dp))
        TableHead(listOf("Metric" to 1f, "Count" to 0.42f, "Rate" to 0.34f))
        teamRows(c).forEach { row ->
            when (row) {
                is Sec -> Text(row.title.uppercase(), style = Type.label(r.ink2, 10.5.sp), modifier = Modifier.fillMaxWidth().padding(start = 14.dp, top = 14.dp, bottom = 4.dp))
                is Metric -> Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(row.label, style = Type.body(r.ink, 15.sp), modifier = Modifier.weight(1f))
                    Text(row.count, style = Type.body(r.ink, 15.sp, FontWeight.SemiBold), textAlign = TextAlign.End, modifier = Modifier.weight(0.42f))
                    Box(Modifier.weight(0.34f), contentAlignment = Alignment.CenterEnd) {
                        row.rate?.let { Pill(pctS(it.a, it.b), toneOf(it.a, it.b, it.hi, it.lo)) }
                    }
                }
            }
            if (row is Metric) Box(Modifier.padding(horizontal = 14.dp)) { Rule() }
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun TableHead(cols: List<Pair<String, Float>>, left: Int = 1) {
    val r = LocalRink.current
    Column {
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp)) {
            cols.forEachIndexed { i, (h, w) ->
                Text(h.uppercase(), style = Type.label(r.ink2, 10.sp), maxLines = 1, overflow = TextOverflow.Clip,
                    textAlign = if (i < left) TextAlign.Start else TextAlign.End, modifier = Modifier.weight(w))
            }
        }
        Box(Modifier.fillMaxWidth().height(2.dp).background(r.ink))
    }
}

@Composable
private fun PlayersCard(t: Team, p: Map<String, PStat>, season: Boolean) {
    val r = LocalRink.current
    val rows = indRows(t, p)
    RinkCard(Line.GOAL, Modifier.gut()) {
        ZoneHead("Players", if (season) "Season totals" else "Faceoffs, battles, turnovers", Modifier.padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 8.dp))
        if (rows.isEmpty()) {
            Text("No player stats yet. Faceoffs, turnovers and board battles credited to players show up here.", style = Type.body(r.ink2, 14.sp),
                modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 16.dp))
            return@RinkCard
        }
        val cols = buildList {
            add("#" to 0.32f); add("Player" to 1f); if (season) add("GP" to 0.34f)
            add("FO" to 0.5f); add("FO %" to 0.62f); add("Battles" to 0.62f); add("TO" to 0.36f)
        }
        TableHead(cols, left = 2)
        rows.forEach { x ->
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(x.num, style = Type.display(20.sp, r.red), modifier = Modifier.weight(0.32f), maxLines = 1)
                Text(x.name, style = Type.body(r.ink, 14.5.sp), modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                val num = TextStyle(color = r.ink, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.End)
                if (season) Text("${x.games}", style = num, modifier = Modifier.weight(0.34f))
                Text("${x.s.FOW}–${x.s.FOL}", style = num, modifier = Modifier.weight(0.5f))
                Box(Modifier.weight(0.62f), contentAlignment = Alignment.CenterEnd) {
                    if (x.s.FOW + x.s.FOL > 0) Pill(pctS(x.s.FOW, x.s.FOW + x.s.FOL), toneOf(x.s.FOW, x.s.FOW + x.s.FOL, 52, 48))
                }
                Text("${x.s.BBW}", style = num, modifier = Modifier.weight(0.62f))
                Text("${x.s.TO}", style = num, modifier = Modifier.weight(0.36f))
            }
            Box(Modifier.padding(horizontal = 14.dp)) { Rule() }
        }
        Spacer(Modifier.height(6.dp))
    }
}

@Composable
private fun SeasonHead(vm: AppViewModel, t: Team, gs: List<Game>) {
    val r = LocalRink.current
    val c = seasonTally(t); val n = gs.size
    val en = c["ENC"] + c["ENU"]; val ex = c["EXC"] + c["EXU"]; val to = c["TOO"] + c["TON"] + c["TOD"]
    val samples = gs.count { it.sample }
    RinkCard(Line.RED, Modifier.gut(), dot = true) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            ZoneHead("Season", t.name)
            Tiles(listOf(
                Tile("Games", "$n", seasonSpan(gs)),
                Tile("Faceoff %", pctS(c["FOW"], c["FOW"] + c["FOL"]), "${c["FOW"]}–${c["FOL"]}", toneOf(c["FOW"], c["FOW"] + c["FOL"], 52, 48)),
                Tile("Ctrl entry %", pctS(c["ENC"], en), "${c["ENC"]} of $en", toneOf(c["ENC"], en, 55, 45)),
                Tile("Ctrl exit %", pctS(c["EXC"], ex), "${c["EXC"]} of $ex", toneOf(c["EXC"], ex, 65, 50)),
                Tile("Turnovers / game", String.format("%.1f", to.toDouble() / n), "$to total"),
                Tile("PP goals", "${c["PPF"]}–${c["PPA"]}", "for – against")
            ))
            if (samples in 1 until n) {
                Notice("These totals include the sample game${if (samples > 1) "s" else ""}.") {
                    Btn(if (samples > 1) "Delete sample games" else "Delete sample game", { vm.askDeleteSamples() }, small = true)
                }
            }
        }
    }
}

@Composable
private fun SeasonGames(vm: AppViewModel, t: Team, gs: List<Game>) {
    val r = LocalRink.current
    val c = seasonTally(t)
    RinkCard(Line.BLUE, Modifier.gut()) {
        ZoneHead("Game by game", "Tap a game", Modifier.padding(start = 14.dp, end = 14.dp, top = 14.dp, bottom = 8.dp))
        TableHead(listOf("Game" to 1f, "FO %" to 0.6f, "Entry" to 0.6f, "Exit" to 0.6f, "TO" to 0.32f))
        gs.forEach { g ->
            val x = tally(g.events)
            Row(Modifier.fillMaxWidth().clickable(role = Role.Button) { vm.openGameStats(g.id) }.padding(horizontal = 14.dp, vertical = 9.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(fmtShort(g.date), style = Type.body(r.ink, 15.sp, FontWeight.Bold)); if (g.sample) SampleTag()
                    }
                    Text("vs ${g.opp}", style = Type.body(r.ink2, 12.5.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                RateCell(x["FOW"], x["FOW"] + x["FOL"], 52, 48); RateCell(x["ENC"], x["ENC"] + x["ENU"], 55, 45); RateCell(x["EXC"], x["EXC"] + x["EXU"], 65, 50)
                Text("${x["TOO"] + x["TON"] + x["TOD"]}", style = Type.body(r.ink, 15.sp, FontWeight.SemiBold), textAlign = TextAlign.End, modifier = Modifier.weight(0.32f))
            }
            Box(Modifier.padding(horizontal = 14.dp)) { Rule() }
        }
        Row(Modifier.fillMaxWidth().background(r.surface2).padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Totals", style = Type.body(r.ink, 15.sp, FontWeight.Bold), modifier = Modifier.weight(1f))
            RateCell(c["FOW"], c["FOW"] + c["FOL"], 52, 48); RateCell(c["ENC"], c["ENC"] + c["ENU"], 55, 45); RateCell(c["EXC"], c["EXC"] + c["EXU"], 65, 50)
            Text("${c["TOO"] + c["TON"] + c["TOD"]}", style = Type.body(r.ink, 15.sp, FontWeight.Bold), textAlign = TextAlign.End, modifier = Modifier.weight(0.32f))
        }
    }
}

@Composable
private fun RowScope.RateCell(a: Int, b: Int, hi: Int, lo: Int) {
    Box(Modifier.weight(0.6f), contentAlignment = Alignment.CenterEnd) { Pill(pctS(a, b), toneOf(a, b, hi, lo)) }
}

