package app.advancedmetrics.tracker.ui

import android.graphics.Typeface
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp

/** The rink palette from the web tools: ice ground, white boards, red line, blue line, goal crease. */
@Immutable
data class Rink(
    val ice: Color, val surface: Color, val surface2: Color, val ink: Color, val ink2: Color, val line: Color,
    val red: Color, val blue: Color, val crease: Color, val creaseInk: Color, val ok: Color, val warn: Color,
    val flash: Color, val onRed: Color, val dark: Boolean
)

val LightRink = Rink(
    ice = Color(0xFFEDF2F6), surface = Color(0xFFFFFFFF), surface2 = Color(0xFFF3F6F9), ink = Color(0xFF0E1924), ink2 = Color(0xFF546372),
    line = Color(0xFFD3DCE4), red = Color(0xFFC8102E), blue = Color(0xFF1A4C9C), crease = Color(0xFFD9ECF9), creaseInk = Color(0xFF0F5A86),
    ok = Color(0xFF2B7A4B), warn = Color(0xFFA8650F), flash = Color(0xFFDBE7F7), onRed = Color(0xFFFFFFFF), dark = false
)
val DarkRink = Rink(
    ice = Color(0xFF0A1117), surface = Color(0xFF111B24), surface2 = Color(0xFF17232E), ink = Color(0xFFE6EDF3), ink2 = Color(0xFF93A2B0),
    line = Color(0xFF263441), red = Color(0xFFFF5A6B), blue = Color(0xFF7DA5F4), crease = Color(0xFF13324A), creaseInk = Color(0xFF8CD0F6),
    ok = Color(0xFF5CCB8C), warn = Color(0xFFF0B35A), flash = Color(0xFF1C3350), onRed = Color(0xFF0A1117), dark = true
)

val LocalRink = staticCompositionLocalOf { LightRink }

/** Condensed bold face for numbers and headings (the phone's built-in condensed sans). */
val Display: FontFamily = FontFamily(Typeface.create("sans-serif-condensed", Typeface.BOLD))

object Type {
    fun display(size: TextUnit, color: Color, spacing: TextUnit = 0.02.em) =
        TextStyle(fontFamily = Display, fontWeight = FontWeight.Bold, fontSize = size, color = color, letterSpacing = spacing)
    fun label(color: Color, size: TextUnit = 11.sp) =
        TextStyle(fontWeight = FontWeight.Bold, fontSize = size, color = color, letterSpacing = 0.14.em)
    fun body(color: Color, size: TextUnit = 15.sp, weight: FontWeight = FontWeight.Normal) =
        TextStyle(fontSize = size, color = color, fontWeight = weight)
}

@Composable
fun MetricsTheme(content: @Composable () -> Unit) {
    val r = if (isSystemInDarkTheme()) DarkRink else LightRink
    val scheme = if (r.dark) darkColorScheme(
        primary = r.ink, onPrimary = r.surface, secondary = r.blue, error = r.red, background = r.ice, onBackground = r.ink,
        surface = r.surface, onSurface = r.ink, surfaceVariant = r.surface2, onSurfaceVariant = r.ink2, outline = r.line,
        surfaceContainerLow = r.surface, surfaceContainerHigh = r.surface, surfaceContainerHighest = r.surface2, surfaceContainer = r.surface,
        inverseSurface = r.ink, inverseOnSurface = r.surface
    ) else lightColorScheme(
        primary = r.ink, onPrimary = r.surface, secondary = r.blue, error = r.red, background = r.ice, onBackground = r.ink,
        surface = r.surface, onSurface = r.ink, surfaceVariant = r.surface2, onSurfaceVariant = r.ink2, outline = r.line,
        surfaceContainerLow = r.surface, surfaceContainerHigh = r.surface, surfaceContainerHighest = r.surface2, surfaceContainer = r.surface,
        inverseSurface = r.ink, inverseOnSurface = r.surface
    )
    CompositionLocalProvider(LocalRink provides r) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
