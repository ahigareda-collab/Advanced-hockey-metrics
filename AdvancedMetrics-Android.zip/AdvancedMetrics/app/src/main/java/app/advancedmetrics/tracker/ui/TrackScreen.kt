package app.advancedmetrics.tracker.ui

import android.view.HapticFeedbackConstants
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.advancedmetrics.tracker.core.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalFoundationApi::class)
fun LazyListScope.trackScreen(vm: AppViewModel, d: AppData) {
    val g = vm.game()
    if (g == null) {
        item(key = "noteam") { TrackNotices(vm) }
        item(key = "empty") {
            RinkCard(Line.RED, Modifier.gut(), dot = true) {
                EmptyState("No game yet", "Start a game to log faceoffs, zone entries and exits, turnovers, power-play goals, one-timers and board battles.") {
                    Btn("Start a game", { vm.openSheet(Sheet.Games(true)) }, kind = BtnKind.PRIMARY)
                    if (vm.engine.activeRoster().isEmpty()) Btn("Add roster", { vm.setTab("setup") })
                }
            }
        }
        return
    }
    stickyHeader(key = "ctl") { Controls(vm, d, g) }
    item(key = "notes") { TrackNotices(vm) }
    item(key = "board") { Board(vm, g) }
}

@Composable
fun EmptyState(title: String, text: String, buttons: @Composable RowScope.() -> Unit) {
    val r = LocalRink.current
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 22.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title.uppercase(), style = Type.display(24.sp, r.ink))
        Text(text, style = Type.body(r.ink2, 14.sp), textAlign = TextAlign.Center)
        Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), content = buttons)
    }
}

@Composable
private fun Controls(vm: AppViewModel, d: AppData, g: Game) {
    val r = LocalRink.current
    // Keep the screen awake while tracking on the bench.
    val view = LocalView.current
    DisposableEffect(view) { view.keepScreenOn = true; onDispose { view.keepScreenOn = false } }
    Column(Modifier.fillMaxWidth().background(r.ice), horizontalAlignment = Alignment.CenterHorizontally) {
        Column(Modifier.gut().padding(vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Segmented(PERS, d.per, { it }, { vm.setPeriod(it) }, Modifier.weight(1f), display = true, describe = { perLong(it) }, height = 42.dp)
                Btn("Undo", { vm.undo() }, enabled = vm.engine.canUndo())
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val last = g.events.lastOrNull()
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    if (last != null) {
                        val t = EV.getValue(last.k)
                        Box(Modifier.size(8.dp).clip(CircleShape).background(when (t.tone) { Tone.GOOD -> r.ok; Tone.BAD -> r.red; else -> r.ink2 }))
                        Text("Last: ${t.name}${last.p?.let { " · " + vm.engine.pName(it) } ?: ""} · ${perShort(last.per)}",
                            style = Type.body(r.ink2, 13.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    } else Text("Nothing logged yet. Tap a button below.", style = Type.body(r.ink2, 13.sp), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Btn("Log", { vm.openSheet(Sheet.Log) }, small = true) { Count(g.events.size) }
            }
        }
        Rule()
    }
}

@Composable
private fun TrackNotices(vm: AppViewModel) {
    val t = vm.team(); val g = vm.game()
    Column(Modifier.gut()) {
        if (t.sample) {
            val own = vm.data.teams.find { !it.sample }
            Notice("Sample team for trying things out.") {
                Btn(if (own != null) "Switch to ${own.name}" else "Set up my team", { vm.myTeam() }, kind = BtnKind.PRIMARY, small = true)
            }
        } else if (g != null && !g.sample && g.date < today() && g.id !in vm.keptOld) {
            Notice("Logging to ${gLabel(g)}, an earlier game.") {
                Btn("Start today’s game", { vm.openSheet(Sheet.Games(true)) }, kind = BtnKind.PRIMARY, small = true)
                Btn("Keep logging here", { vm.keepOld(g.id) }, small = true)
            }
        }
    }
}

@Composable
private fun Board(vm: AppViewModel, g: Game) {
    val r = LocalRink.current
    val c = tally(g.events).c
    val who = vm.engine.askingWho()
    RinkCard(Line.RED, Modifier.gut(), dot = true) {
        BoxWithConstraints(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
            val stacked = maxWidth < 300.dp   // very narrow screens: label above full-width buttons
            Column {
                GROUPS.forEachIndexed { i, gr ->
                    if (i > 0) Rule()
                    val label: @Composable () -> Unit = {
                        Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
                            Box(Modifier.width(22.dp).height(if (gr.line == Line.GOAL) 2.dp else 4.dp).clip(RoundedCornerShape(2.dp))
                                .background(if (gr.line == Line.BLUE) r.blue else r.red))
                            Text(gr.title.uppercase(), style = Type.display(16.sp, r.ink), lineHeight = 16.sp)
                            Text(groupMeta(gr.id, c), style = Type.body(r.ink2, 12.sp, FontWeight.Bold), maxLines = 1)
                        }
                    }
                    if (stacked) {
                        Column(Modifier.padding(vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            label(); TapRow(vm, gr, c, who)
                        }
                    } else {
                        Row(Modifier.padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(Modifier.weight(0.29f)) { label() }
                            Box(Modifier.weight(0.71f)) { TapRow(vm, gr, c, who) }
                        }
                    }
                }
            }
        }
        Rule()
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            when {
                who -> {
                    Icon(Icons.Default.Person, null, tint = r.blue, modifier = Modifier.size(14.dp))
                    Text("These buttons ask which player. Undo takes back the last change.", style = Type.body(r.ink2, 13.sp))
                }
                vm.data.askWho -> {
                    Text("Add your roster to credit players.", style = Type.body(r.ink2, 13.sp), modifier = Modifier.weight(1f))
                    Btn("Add roster", { vm.setTab("setup") }, small = true)
                }
                else -> {
                    Text("Player credit is off, so everything logs to the team.", style = Type.body(r.ink2, 13.sp), modifier = Modifier.weight(1f))
                    Btn("Turn on", { vm.setAskWho(true) }, small = true)
                }
            }
        }
    }
}

@Composable
private fun TapRow(vm: AppViewModel, gr: Group, c: Map<String, Int>, who: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        gr.keys.forEach { k -> TapButton(vm, k, c[k] ?: 0, gr.pp, who, Modifier.weight(1f)) }
    }
}

@Composable
private fun TapButton(vm: AppViewModel, k: String, n: Int, pp: Boolean, who: Boolean, modifier: Modifier) {
    val r = LocalRink.current
    val t = EV.getValue(k)
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val flash = remember { Animatable(0f) }
    val base = if (pp) r.crease else r.surface2
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier.heightIn(min = 64.dp).clip(shape).background(lerp(base, r.flash, flash.value))
            .border(1.dp, if (pp) r.red else lerp(r.line, r.blue, flash.value), shape)
            .clickable(role = Role.Button) {
                if (vm.tapStat(k)) {
                    view.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    scope.launch { flash.snapTo(1f); flash.animateTo(0f, tween(450)) }
                }
            }
            .semantics { contentDescription = "${t.name}: $n" + if (t.ind && who) ". Asks which player" else "" }
            .padding(horizontal = 3.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text("$n", style = Type.display(30.sp, when (t.tone) { Tone.GOOD -> r.ok; Tone.BAD -> r.red; else -> r.ink }), lineHeight = 30.sp)
            Text(t.lbl.uppercase(), style = Type.label(r.ink2, 10.5.sp), textAlign = TextAlign.Center, maxLines = 2, lineHeight = 12.sp)
        }
        if (t.ind && who) Icon(Icons.Default.Person, null, tint = r.blue, modifier = Modifier.align(Alignment.TopEnd).size(13.dp))
    }
}
