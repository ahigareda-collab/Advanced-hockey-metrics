package app.advancedmetrics.tracker.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

class CoreTest {
    @Test fun webBackupWithDamageLoadsAndRepairs() {
        val old = """{"teams":[{"id":"t1","name":"Sample Team","roster":[{"id":"p1","num":9,"name":"Costa"}],"games":[{"id":"g1","date":"2026-10-17","opp":"Sample opponent","sample":true,
          "events":[{"id":"e1","k":"FOW","p":"p1","per":"1","ts":0.53},{"id":"e2","k":"GOAL","per":"1"},{"id":"e3","k":"TOO","p":"ghost","per":7}]}],"gameId":"g1"}],
          "teamId":"t1","tab":"season"}"""
        val l = parseSaved(old)!!
        val g = l.data.teams[0].games[0]
        assertEquals(listOf("FOW", "TOO"), g.events.map { it.k })
        assertEquals("1", g.events[1].per)
        assertEquals("9", l.data.teams[0].roster[0].num)
        assertEquals("stats", l.data.tab); assertEquals("season", l.data.statsView)
        assertEquals(3, l.fixed)   // the unknown stat, the missing player and the bad period, each counted once
        assertEquals(l.data, parseSaved(toJson(l.data))!!.data)
        assertNull(parseSaved("nope")); assertNull(parseSaved("{\"teams\":[]}"))
    }

    @Test fun trackingUndoAndStats() {
        val e = Engine(seedData())
        e.myTeam(); e.addPlayer("9", "Mike Costa")
        assertNull(e.startGame("2026-10-24", "Cherry Hill"))
        val costa = e.team().roster.first().id
        repeat(3) { e.logEvent("FOW", costa) }; e.logEvent("FOL", null); e.logEvent("ENC", costa)
        val g = e.game()!!
        assertEquals(5, g.events.size)
        assertNull(g.events.last().p)                     // team stats never take a player
        val c = tally(g.events)
        assertEquals("75%", pctS(c["FOW"], c["FOW"] + c["FOL"]))
        val ids = g.events.map { it.id }
        e.deleteEntry(ids[4]); e.deleteEntry(ids[3]); e.undo(); e.undo()
        assertEquals(ids, e.game()!!.events.map { it.id })
        e.undo()
        assertEquals(4, e.game()!!.events.size)
    }

    @Test fun rosterPaste() {
        val sheet = parseRoster("Number\tFirst Name\tLast Name\n12\tLiam\tCarter\n22\tOwen\tPatel")
        assertEquals(listOf(RosterLine("12", "Liam Carter"), RosterLine("22", "Owen Patel")), sheet.rows)
        val p = parseRoster("9 Mike Costa\n27, Nolan, Sam\n#18 Jack Moreno LW\n???")
        assertEquals(listOf(RosterLine("9", "Mike Costa"), RosterLine("27", "Sam Nolan"), RosterLine("18", "Jack Moreno")), p.rows)
        assertEquals(1, p.skipped)
    }

    @Test fun workbookIsAValidZip() {
        val e = Engine(seedData())
        val bytes = buildWorkbook(e.team(), e.game())
        val names = ArrayList<String>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z -> while (true) { val en = z.nextEntry ?: break; names.add(en.name) } }
        assertTrue("xl/workbook.xml" in names && "xl/worksheets/sheet4.xml" in names)
        assertNotNull(names.find { it == "[Content_Types].xml" })
    }

    @Test fun undoNeverBringsBackAStatForADeletedPlayer() {
        fun engine(): Engine = Engine(seedData()).apply {
            myTeam(); addPlayer("9", "Mike Costa"); addPlayer("12", "Liam Carter"); assertNull(startGame("2026-10-24", "Cherry Hill"))
        }
        // Deleting Costa's only stat and then removing him used to delete him outright, so Undo restored a stat for nobody.
        var e = engine(); var costa = e.team().roster.first { it.name == "Mike Costa" }.id
        e.deleteEntry(e.logEvent("FOW", costa)!!.id); e.removePlayer(costa); e.undo()
        assertEquals(costa, e.game()!!.events.single().p); assertNotNull(e.player(costa))
        // Same through an edit: the credit moves to Carter, Costa is removed, then Undo moves it back.
        e = engine(); costa = e.team().roster.first { it.name == "Mike Costa" }.id
        val carter = e.team().roster.first { it.name == "Liam Carter" }.id
        e.editEntry(e.logEvent("FOW", costa)!!.id, p = carter, setP = true); e.removePlayer(costa); e.undo()
        assertEquals(costa, e.game()!!.events.single().p); assertNotNull(e.player(costa))
        // Someone with no stats and nothing to undo is still deleted.
        e.removePlayer(carter); assertNull(e.player(carter))
    }

    @Test fun duplicateIdsInABackupPointAtTheFirstMatch() {
        // The web tracker finds the first item with an id, so a repaired backup must credit the same player and game.
        val dup = """{"teams":[{"id":"t1","name":"Hawks","roster":[{"id":"p1","num":"9","name":"Costa"},{"id":"p1","num":"27","name":"Nolan"}],
          "games":[{"id":"g1","date":"2026-10-17","opp":"Bears","events":[{"id":"e1","k":"FOW","p":"p1","per":"1","ts":0}]},
          {"id":"g1","date":"2026-10-18","opp":"Wolves","events":[]}],"gameId":"g1"}],"teamId":"t1"}"""
        val l = parseSaved(dup)!!; val t = l.data.teams.single()
        assertEquals("Costa", t.roster.first { it.id == t.games[0].events[0].p }.name)
        assertEquals("Bears", t.games.first { it.id == t.gameId }.opp)
        assertEquals(2, l.fixed)   // the second player's id and the second game's id
    }

    @Test fun backupTextQuirks() {
        // Notepad on Windows starts UTF-8 files with a byte-order mark.
        assertNotNull(parseSaved("\uFEFF" + toJson(seedData())))
        // \u needs exactly four hex digits; a sign is not one.
        assertEquals(JStr("A"), Json.parse("\"\\u0041\""))
        for (bad in listOf("\"\\u-041\"", "\"\\u+041\"", "\"\\u04\"")) assertThrows(JsonError::class.java) { Json.parse(bad) }
    }

    @Test fun workbookRateColorsMatchTheRoundedPercent() {
        // 16-15 is 51.6% and 10-11 is 47.6%. The app and PDF round them to 52% (good) and 48% (neutral); Excel must agree.
        fun game(id: String, date: String, w: Int, l: Int) =
            Game(id, date, "Bears", List(w) { Ev("$id-w$it", "FOW", null, "1", 0) } + List(l) { Ev("$id-l$it", "FOL", null, "1", 0) })
        val t = Team("t1", "Hawks", emptyList(), listOf(game("g1", "2026-10-20", 16, 15), game("g2", "2026-10-21", 10, 11)), "g2")
        val x = unzip(buildWorkbook(t, null))
        val season = x.getValue("xl/worksheets/sheet1.xml"); val styles = x.getValue("xl/styles.xml")
        fun color(ref: String): String {
            val s = Regex("<c r=\"$ref\" s=\"(\\d+)\"").find(season)!!.groupValues[1].toInt()
            val xfs = Regex("<cellXfs.*?</cellXfs>").find(styles)!!.value
            val font = Regex("<xf [^>]*fontId=\"(\\d+)\"").findAll(xfs).elementAt(s).groupValues[1].toInt()
            val f = Regex("<font>(.*?)</font>").findAll(styles).elementAt(font).groupValues[1]
            return Regex("rgb=\"FF(\\w{6})\"").find(f)?.groupValues?.get(1) ?: ""
        }
        assertEquals("2B7A4B", color("E5"))   // first game's FO %: good
        assertEquals("0E1924", color("E6"))   // second game's FO %: neutral, not red
    }

    @Test fun workbookSheetNamesStayUnique() {
        val wb = unzip(Xlsx.build(List(3) { XSheet("Game", emptyList()) }, XStyles())).getValue("xl/workbook.xml")
        assertEquals(listOf("Game", "Game 2", "Game 3"), Regex("<sheet name=\"([^\"]*)\"").findAll(wb).map { it.groupValues[1] }.toList())
    }

    private fun unzip(bytes: ByteArray): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z -> while (true) { val en = z.nextEntry ?: break; out[en.name] = z.readBytes().toString(Charsets.UTF_8) } }
        return out
    }
}
