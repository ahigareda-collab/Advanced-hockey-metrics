package app.advancedmetrics.tracker.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.util.zip.ZipInputStream

class CoreTest {
    @Test fun webBackupWithDamageLoadsAndRepairs() {
        val old = """{"teams":[{"id":"t1","name":"Sample Team","roster":[{"id":"p1","num":9,"name":"Costa"}],"games":[{"id":"g1","date":"2026-10-17","opp":"Sample opponent","sample":true,
          "events":[{"id":"e1","k":"FOW","p":"p1","per":"1","ts":0.53},{"id":"e2","k":"GOAL","per":"1"},{"id":"e3","k":"TOO","p":"ghost","per":7}]}],"gameId":"g1"}],
          "teamId":"t1","tab":"season"}"""
        val l = parseSaved(old)!!
        val g = l.data.teams[0].games[0]
        assertEquals(listOf("FOW", "TOO"), g.events.map { it.k })
        assertEquals("1", g.events[1].per)
        assertEquals("9", l.data.teams[0].roster[0].num)
        assertEquals("stats", l.data.tab); assertEquals("season", l.data.statsView)
        assertEquals(l.data, parseSaved(toJson(l.data))!!.data)
        assertNull(parseSaved("nope")); assertNull(parseSaved("{\"teams\":[]}"))
    }

    @Test fun trackingUndoAndStats() {
        val e = Engine(seedData())
        e.myTeam(); e.addPlayer("9", "Mike Costa")
        assertNull(e.startGame("2026-10-24", "Cherry Hill"))
        val costa = e.team().roster.first().id
        repeat(3) { e.logEvent("FOW", costa) }; e.logEvent("FOL", null); e.logEvent("ENC", costa)
        val g = e.game()!!
        assertEquals(5, g.events.size)
        assertNull(g.events.last().p)                     // team stats never take a player
        val c = tally(g.events)
        assertEquals("75%", pctS(c["FOW"], c["FOW"] + c["FOL"]))
        val ids = g.events.map { it.id }
        e.deleteEntry(ids[4]); e.deleteEntry(ids[3]); e.undo(); e.undo()
        assertEquals(ids, e.game()!!.events.map { it.id })
        e.undo()
        assertEquals(4, e.game()!!.events.size)
    }

    @Test fun rosterPaste() {
        val sheet = parseRoster("Number\tFirst Name\tLast Name\n12\tLiam\tCarter\n22\tOwen\tPatel")
        assertEquals(listOf(RosterLine("12", "Liam Carter"), RosterLine("22", "Owen Patel")), sheet.rows)
        val p = parseRoster("9 Mike Costa\n27, Nolan, Sam\n#18 Jack Moreno LW\n???")
        assertEquals(listOf(RosterLine("9", "Mike Costa"), RosterLine("27", "Sam Nolan"), RosterLine("18", "Jack Moreno")), p.rows)
        assertEquals(1, p.skipped)
    }

    @Test fun workbookIsAValidZip() {
        val e = Engine(seedData())
        val bytes = buildWorkbook(e.team(), e.game())
        val names = ArrayList<String>()
        ZipInputStream(ByteArrayInputStream(bytes)).use { z -> while (true) { val en = z.nextEntry ?: break; names.add(en.name) } }
        assertTrue("xl/workbook.xml" in names && "xl/worksheets/sheet4.xml" in names)
        assertNotNull(names.find { it == "[Content_Types].xml" })
    }
}
